package com.totem_barberia_vip.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
