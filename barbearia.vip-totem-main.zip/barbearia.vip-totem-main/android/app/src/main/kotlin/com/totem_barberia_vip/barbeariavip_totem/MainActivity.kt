package com.totem_barberia_vip.barbeariavip_totem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
