---
name: Nova Tarefa
about: Criação de uma nova tarefa
title: "[Feature] "
labels: []
assignees: []
---

### Descrição

### Tarefas
- [ ] 

### Critérios de aceitação
- [ ]

### Referências
