import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomScaffoldMessenger {
  final BuildContext context;
  final AppColors appColors;

  CustomScaffoldMessenger({required this.context}) : appColors = AppColors();

  void show({required String message, int seconds = 3}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Container(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 50),
          child: Text(
            message,
            style: TextStyle(color: appColors.textWhite, fontSize: 20),
          ),
        ),
        backgroundColor: appColors.backGroundRed,
        duration: Duration(seconds: seconds),
      ),
    );
  }
}
