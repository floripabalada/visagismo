import 'package:flutter/material.dart';
import 'dart:async';

import 'package:vip_totem/shared/app_colors.dart';

class CustomRotatingText extends StatefulWidget {
  final List<String> texts;
  final int seconds;
  final int secondsExchange;
  final TextStyle style;

  const CustomRotatingText(
      {super.key,
      required this.texts,
      required this.secondsExchange,
      required this.seconds,
      required this.style});

  @override
  CustomRotatingTextState createState() => CustomRotatingTextState();
}

class CustomRotatingTextState extends State<CustomRotatingText> {
  List<String> _texts = [];
  int _secondsExchange = 2;
  TextStyle? _style;

  int _currentIndex = 0;
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    _startTimer(widget.seconds);

    _texts = widget.texts;
    _secondsExchange = widget.secondsExchange;
    _style = widget.style;
  }

  void _startTimer(setSeconts) {
    _timer = Timer.periodic(Duration(seconds: setSeconts), (timer) {
      setState(() {
        _currentIndex = (_currentIndex + 1) % _texts.length;
      });
    });
  }

  @override
  void dispose() {
    _timer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    final setStyle = _style ??
        TextStyle(
            fontSize: 14, fontWeight: FontWeight.bold, color: appColors.gray);

    return SizedBox(
        child: AnimatedSwitcher(
      duration: Duration(milliseconds: _secondsExchange),
      child: Text(
        _texts[_currentIndex],
        key: ValueKey<int>(_currentIndex),
        style: setStyle,
      ),
    ));
  }
}
