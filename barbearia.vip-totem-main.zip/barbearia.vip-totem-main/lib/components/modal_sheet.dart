import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class ModalSheet {
  static void show(BuildContext context, Widget Function() contentChildren,
      {bool isDismissible = true,
      bool enableDrag = true,
      double height = 0.8}) {
    final appColors = AppColors();

    showModalBottomSheet(
      isDismissible: isDismissible,
      enableDrag: enableDrag,
      isScrollControlled: true,
      context: context,
      builder: (BuildContext context) {
        // pega o tamanho da tela
        final screenHeight = MediaQuery.of(context).size.height;

        return Container(
          color: appColors.background,
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: SafeArea(
            // Envolve o modal para evitar que ele "grude" nas bordas da tela
            child: SizedBox(
              height: screenHeight *
                  height, // Limita o modal a 90% da altura da tela
              child: Column(
                children: [
                  if (enableDrag)
                    Padding(
                      padding: const EdgeInsets.only(top: 10, bottom: 20),
                      child: Center(
                        child: Container(
                          width: 60,
                          height: 5,
                          decoration: BoxDecoration(
                            color: appColors.backgroundSecundary,
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                      ),
                    ),
                  Expanded(
                    // Permite que o conteúdo ocupe o espaço restante e seja rolável
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          contentChildren(),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
