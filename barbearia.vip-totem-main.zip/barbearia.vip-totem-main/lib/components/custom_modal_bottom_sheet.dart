import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomModalBottomSheet {
  final BuildContext context;

  CustomModalBottomSheet(this.context);

  Future<void> show({
    required Widget child,
    double height = 300,
    bool isDismissible = true,
    bool enableDrag = true,
  }) {
    final appColors = AppColors();

    return showModalBottomSheet<void>(
      context: context,
      isDismissible: isDismissible,
      useRootNavigator: true,
      backgroundColor: Colors.transparent,
      enableDrag: enableDrag,
      isScrollControlled: true,
      builder: (BuildContext context) {
        return SafeArea(
          child: Container(
            height: height,
            padding: const EdgeInsets.all(15),
            width: double.infinity,
            decoration: BoxDecoration(
              color: appColors.backGroundQuinary,
              borderRadius:
                  const BorderRadius.vertical(top: Radius.circular(20)),
            ),
            child: Column(
              children: [
                if (enableDrag)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 30),
                    child: Center(
                      child: Container(
                        width: 60,
                        height: 5,
                        decoration: BoxDecoration(
                          color: appColors.textYellow,
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                Expanded(child: child),
              ],
            ),
          ),
        );
      },
    );
  }

  void close() {
    Navigator.of(context, rootNavigator: true).pop();
  }

  Future<void> showLoading({String text = 'Carregando...'}) {
    return show(
      height: 120,
      isDismissible: false,
      enableDrag: false,
      child: LoadingModal(text: text),
    );
  }
}

class LoadingModal extends StatelessWidget {
  final String text;

  const LoadingModal({super.key, this.text = 'Carregando...'});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: appColors.textGreen,
            strokeWidth: 2,
          ),
          const SizedBox(width: 10),
          Text(
            text,
            style: TextStyle(
              fontSize: 20,
              color: appColors.textGreen,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
