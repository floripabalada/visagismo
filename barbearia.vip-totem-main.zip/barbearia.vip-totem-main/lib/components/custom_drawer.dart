import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomDrawer extends StatelessWidget {
  final double backgroundOpacity;

  const CustomDrawer({super.key, this.backgroundOpacity = 0.85});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Drawer(
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
      ),
      child: Stack(
        children: [
          Container(
            color: appColors.background.withOpacity(backgroundOpacity),
          ),
          // Conteúdo do Drawer
          Container(
            margin: const EdgeInsets.only(top: 130, left: 20),
            child: ListView(
              padding: const EdgeInsets.only(top: 10),
              //   children: const [Menu()],
            ),
          ),
        ],
      ),
    );
  }
}
