import 'package:vip_totem/shared/app_colors.dart';
import 'package:flutter/material.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
  final String? title;

  const CustomAppBar({super.key, this.title = ''});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return AppBar(
      backgroundColor: appColors.background,
      surfaceTintColor: appColors.background,
      elevation: 0,
      // title: Text(title),
      //   actions: actions,
      leading: Builder(
        builder: (context) {
          return Row(children: [
            IconButton(
              icon: Icon(
                Icons.arrow_back,
                color: appColors.backGroundQuinary,
                size: 40,
              ),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ]);
        },
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
