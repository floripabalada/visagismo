import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class Option {
  final String id;
  final String description;

  Option({required this.id, required this.description});
}

class CustomRadioButton extends StatefulWidget {
  final List<Option> options;
  final String? optionSelected;
  final Function(String) onOptionSelected;

  const CustomRadioButton({
    super.key,
    required this.options,
    required this.optionSelected,
    required this.onOptionSelected,
  });

  @override
  CustomRadioButtonState createState() => CustomRadioButtonState();
}

class CustomRadioButtonState extends State<CustomRadioButton> {
  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 10.0,
      runSpacing: 10.0,
      children: List.generate(widget.options.length, (index) {
        return TweenAnimationBuilder<double>(
          duration: Duration(milliseconds: 150 + (index * 100)),
          tween: Tween<double>(begin: 0, end: 1),
          builder: (context, value, child) {
            return Transform.scale(
              scale: value,
              child: Opacity(
                opacity: value,
                child: child,
              ),
            );
          },
          child: buildOption(widget.options[index]),
        );
      }),
    );
  }

  Widget buildOption(Option option) {
    final appColors = AppColors();

    String? itemSelected = widget.optionSelected;

    return Stack(
      children: [
        TextButton(
          onPressed: () {
            // seta o dado selecionado
            setState(() {
              itemSelected = option.id;
            });

            // executa a função
            widget.onOptionSelected(option.id);
          },
          style: TextButton.styleFrom(
            backgroundColor: itemSelected == option.id
                ? appColors.backgroundSecundary
                : appColors.backGroundQuinary,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(5)),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 30),
            child: SizedBox(
              width: 120, // Ajuste conforme necessário
              height: 120,
              child: Center(
                child: Text(
                  // softWrap: false,
                  option.description,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: appColors.textWhite,
                      fontSize: 16,
                      fontWeight: itemSelected == option.id
                          ? FontWeight.bold
                          : FontWeight.normal),
                ),
              ),
            ),
          ),
        ),
        if (itemSelected == option.id)
          Positioned(
            top: 5,
            right: 18,
            child: Icon(
              Icons.check,
              color: appColors.textYellow,
              size: 50,
            ),
          ),
      ],
    );
  }
}
