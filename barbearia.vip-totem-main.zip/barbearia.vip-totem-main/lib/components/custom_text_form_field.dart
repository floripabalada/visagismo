import 'package:vip_totem/components/custom_virtual_keyboard.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:flutter/material.dart';

class CustomTextFormField extends StatefulWidget {
  final TextEditingController? controller;
  final String label;
  final IconData icon;
  final double iconSize;
  final bool obscureText;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final FocusNode? focusNode;
  final double fontSize;
  final double fontSizeLabel;
  final bool? enabled;
  final bool isNumericKeyboard;

  const CustomTextFormField({
    super.key,
    this.controller,
    required this.label,
    required this.icon,
    this.iconSize = 40,
    this.obscureText = false,
    this.validator,
    this.keyboardType = TextInputType.text,
    this.focusNode,
    this.fontSize = 50,
    this.fontSizeLabel = 30,
    this.enabled = true,
    this.isNumericKeyboard = false,
  });

  @override
  State<CustomTextFormField> createState() => CustomTextFormFieldState();
}

class CustomTextFormFieldState extends State<CustomTextFormField> {
  bool showKeyboard = false;

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      child: Column(
        children: [
          TextFormField(
            onTap: () {
              setState(() {
                showKeyboard = !showKeyboard;
              });
            },
            controller: widget.controller,
            obscureText: widget.obscureText,
            keyboardType: widget.keyboardType,
            validator: widget.validator,
            focusNode: widget.focusNode,
            enabled: widget.enabled,
            style: TextStyle(
              color: widget.enabled == true
                  ? appColors.textGrey
                  : appColors.textGrey3,
              fontSize: widget.fontSize,
            ),
            textInputAction: TextInputAction.done,
            decoration: InputDecoration(
              labelStyle: TextStyle(
                color: appColors.textGrey,
                fontSize: widget.fontSizeLabel,
              ),
              labelText: widget.label,
              border: const OutlineInputBorder(),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: appColors.backgroundGray),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: appColors.backgroundQuaternary),
              ),
              prefixIcon: Padding(
                padding: const EdgeInsets.all(30),
                child: Icon(
                  widget.icon,
                  color: appColors.backgroundGray,
                  size: widget.iconSize,
                ),
              ),
              contentPadding: EdgeInsets.symmetric(
                vertical: 16,
                horizontal: widget.fontSize,
              ),
            ),
          ),
          if (showKeyboard)
            CustomVirtualKeyboard(
              controller: widget.controller,
              isNumeric: widget.isNumericKeyboard,
            ),
        ],
      ),
    );
  }
}
