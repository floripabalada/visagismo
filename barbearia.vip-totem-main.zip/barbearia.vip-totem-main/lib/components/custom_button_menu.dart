import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomButtonMenu extends StatelessWidget {
  final Function()? onPressed;
  final String title;
  final String description;
  final IconData icon;
  final bool isDisabled;

  const CustomButtonMenu({
    super.key,
    required this.onPressed,
    required this.title,
    required this.description,
    required this.icon,
    this.isDisabled = false,
  });

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return SizedBox(
      child: TextButton(
        onPressed: isDisabled ? null : onPressed,
        style: TextButton.styleFrom(
          backgroundColor: appColors.backGroundQuinary,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10)),
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 20, horizontal: 20),
          child: Row(
            // Removido o Expanded daqui
            children: [
              Expanded(
                child: Center(
                  child: Icon(
                    icon,
                    color: !isDisabled
                        ? appColors.backgroundSecundary
                        : appColors.gray,
                    size: 75,
                  ),
                ),
              ),
              Expanded(
                flex: 4,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        color:
                            !isDisabled ? appColors.textGreen : appColors.gray,
                        fontSize: 36,
                      ),
                    ),
                    Text(
                      description,
                      style: TextStyle(
                        color:
                            !isDisabled ? appColors.textGrey4 : appColors.gray,
                        fontSize: 18,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
