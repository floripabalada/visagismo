import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomBoxSeparator extends StatelessWidget {
  final double height;
  final Color? color;

  const CustomBoxSeparator({super.key, required this.height, this.color});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    return Container(
      height: height,
      decoration: BoxDecoration(
          border: Border(
              bottom: BorderSide(
                  color: color ?? appColors.backgroundSecundary, width: 1))),
    );
  }
}
