import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomRoundImage extends StatelessWidget {
  final String imagePath;
  final double width;
  final double height;
  final double borderWidth;
  final Color? borderColor;
  final dynamic backgroundColor;

  const CustomRoundImage(
      {super.key,
      required this.imagePath,
      this.height = 100,
      this.width = 100,
      this.borderWidth = 2.0,
      this.borderColor,
      this.backgroundColor});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    Color setBorderColor = borderColor ?? appColors.background;

    return Container(
      width: width + 10,
      height: height + 10,
      decoration: borderWidth != 0.0
          ? BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: setBorderColor,
                width: borderWidth,
              ),
            )
          : null,
      child: ClipOval(
        child: Image.asset(
          imagePath,
          width: width,
          height: height,
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}
