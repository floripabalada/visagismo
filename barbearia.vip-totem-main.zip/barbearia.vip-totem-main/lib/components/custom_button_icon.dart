import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomButtonIcon extends StatelessWidget {
  final Function()? onPressed;
  final IconData icon;
  final double size;
  final Color? color;
  final Color? background;

  const CustomButtonIcon(
      {super.key,
      this.onPressed,
      required this.icon,
      this.size = 40,
      this.color,
      this.background});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    Color setColor = color ?? appColors.iconPrimary;
    Color setBackground = background ?? appColors.background;

    return Material(
        color: setBackground,
        borderRadius: BorderRadius.circular(50),
        child: IconButton(
            iconSize: size,
            color: setColor,
            onPressed: onPressed,
            icon: Icon(icon)));
  }
}
