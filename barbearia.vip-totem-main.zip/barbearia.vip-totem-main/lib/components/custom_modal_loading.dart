import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomModalLoading {
  static Future<void> show(
      {required BuildContext context, required String text}) {
    final appColors = AppColors();

    return showDialog<BuildContext>(
        context: context,
        barrierDismissible: false,
        builder: (BuildContext builderContext) {
          return AlertDialog(
            backgroundColor: appColors.background,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            content: Row(
              children: [
                CircularProgressIndicator(
                  color: appColors.backgroundQuaternary,
                  strokeWidth: 3,
                ),
                const SizedBox(width: 20),
                Text(text,
                    style: TextStyle(
                        fontSize: 20,
                        color: appColors.quaternary,
                        fontWeight: FontWeight.bold))
              ],
            ),
          );
        });
  }

  static void close(BuildContext context) {
    if (Navigator.of(context).canPop()) {
      Navigator.of(context).pop();
    }
  }
// }
}
