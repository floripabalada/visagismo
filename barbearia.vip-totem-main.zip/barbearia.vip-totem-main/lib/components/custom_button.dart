import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomButton extends StatelessWidget {
  final Function()? onPressed;
  final String text;
  final IconData icon;
  final String positionIcon;
  final Color? backgroundColor;
  final Color? textColor;
  final Color? iconColor;

  const CustomButton(
      {super.key,
      required this.onPressed,
      required this.text,
      required this.icon,
      this.positionIcon = 'before',
      this.backgroundColor,
      this.textColor,
      this.iconColor});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    Color setBackgroundColor = backgroundColor ?? appColors.backGroundQuinary;
    Color setTextColor = textColor ?? appColors.textGreen;
    Color setIconColor = iconColor ?? appColors.textGreen;

    return SizedBox(
      width: double.infinity,
      child: Container(
        decoration: BoxDecoration(
          color: setBackgroundColor,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              offset: const Offset(0, 0),
              blurRadius: 10,
            ),
          ],
        ),
        child: TextButton(
          onPressed: onPressed,
          style: TextButton.styleFrom(
            // Elevation removida, pois estamos usando boxShadow no Container
            elevation: 0,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(5)),
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 5),
            child: Wrap(
              children: [
                Stack(
                  children: [
                    positionIcon == 'after'
                        ? Positioned(
                            left: -10,
                            child: Icon(
                              icon,
                              color: setIconColor,
                              size: 45,
                            ))
                        : const SizedBox.shrink(),
                    SizedBox(
                      height: 40,
                      child: Align(
                        alignment: Alignment.center,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            positionIcon == 'center'
                                ? Icon(
                                    icon,
                                    color: setIconColor,
                                    size: 45,
                                  )
                                : const SizedBox.shrink(),
                            Text(
                              text,
                              style: TextStyle(
                                color: setTextColor,
                                fontSize: 24,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    positionIcon == 'before'
                        ? Positioned(
                            right: -10,
                            child: Icon(
                              icon,
                              color: setIconColor,
                              size: 45,
                            ))
                        : const SizedBox.shrink(),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
