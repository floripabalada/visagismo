import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomLottieScaffold extends StatelessWidget {
  final String message;

  const CustomLottieScaffold({
    super.key,
    required this.message,
  });

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Scaffold(
        body: Center(
      child: SizedBox(
        // backgroundColor: Colors.transparent,
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(
            color: appColors.background,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Lottie.asset(
                repeat: false,
                'assets/lottie/lottie-success.json',
                width: 400,
                height: 400,
                fit: BoxFit.cover,
              ),
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 30,
                  color: appColors.textPrimary,
                ),
              ),
            ],
          ),
        ),
      ),
    ));
  }
}
