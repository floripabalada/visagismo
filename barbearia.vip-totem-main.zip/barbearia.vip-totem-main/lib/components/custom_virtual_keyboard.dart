import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:virtual_keyboard_multi_language/virtual_keyboard_multi_language.dart';

class CustomVirtualKeyboard extends StatelessWidget {
  final dynamic controller;
  final double height;
  final Color keyColor;
  final Color textColor;
  final VoidCallback? onBackspace;
  final bool isNumeric;

  const CustomVirtualKeyboard({
    super.key,
    required this.controller,
    this.height = 300,
    this.keyColor = Colors.white,
    this.textColor = Colors.black,
    this.onBackspace,
    this.isNumeric = false,
  });

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    return Container(
      color: appColors.backGroundQuinary,
      child: VirtualKeyboard(
        height: 300,
        fontSize: 30,
        textColor: appColors.textGreen,
        textController: controller,
        type: isNumeric
            ? VirtualKeyboardType.Numeric
            : VirtualKeyboardType.Alphanumeric,
        // defaultLayouts: const [
        //   VirtualKeyboardDefaultLayouts.Portuguese,
        //   VirtualKeyboardDefaultLayouts.English,
        // ],
        postKeyPress: (VirtualKeyboardKey key) {
          //
          controller.selection = TextSelection.fromPosition(
            TextPosition(offset: controller.text.length),
          );
        },
      ),
    );
  }
}
