import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class InfoLabel extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;

  const InfoLabel(
      {super.key,
      required this.label,
      required this.value,
      required this.icon});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      decoration: BoxDecoration(
        color: Colors.blueAccent.withOpacity(0.1),
        borderRadius: BorderRadius.circular(8),
        // border: Border.all(color: AppColors.textGrey, width: 0.5),
      ),
      child: Row(
        children: [
          Icon(icon, size: 30, color: appColors.textGrey),
          const SizedBox(width: 8),
          Expanded(
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(
                  '$label: ',
                  style: TextStyle(
                    fontSize: 16,
                    color: appColors.textGrey,
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: appColors.textWhite,
                  ),
                ),
              ]))
        ],
      ),
    );
  }
}
