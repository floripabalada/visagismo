import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class CustomImage extends StatelessWidget {
  final String imagePath;
  final double? width;
  final double? height;
  final BoxFit fit;
  final String type;

  const CustomImage(
      {super.key,
      required this.imagePath,
      this.width,
      this.height,
      this.fit = BoxFit.contain,
      this.type = 'png'});

  @override
  Widget build(BuildContext context) {
    return type == 'png'
        ? Image(
            image: imagePath.startsWith('http')
                ? NetworkImage(imagePath)
                : AssetImage(imagePath) as ImageProvider,
            width: width,
            height: height,
            fit: fit,
          )
        : SvgPicture.asset(
            imagePath,
            width: width, // Defina a largura
            height: height,
            fit: fit, // Defina a altura
          );
  }
}
