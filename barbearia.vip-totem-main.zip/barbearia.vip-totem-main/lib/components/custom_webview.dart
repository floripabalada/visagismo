import 'package:webview_flutter/webview_flutter.dart';

class CustomWebview {
  static controller(String url) {
    return WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(url));
  }
}
