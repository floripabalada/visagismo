// import 'package:vip_totem/config/app_colors.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:vip_totem/page/sys/dashboard/dashboard_sys.dart';
// import 'package:vip_totem/provider/auth_provider.dart';
// import 'package:vip_totem/util/route_util.dart';

// class CustomAppBarLogo extends ConsumerWidget implements PreferredSizeWidget {
//   final List<Widget>? actions;
//   final bool? hasBackButton;

//   const CustomAppBarLogo({super.key, this.actions, this.hasBackButton = false});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // seta o provider
//     final provider = ref.watch(authProvider);

//     String firstName = '';

//     if (provider.user != null) {
//       // seta o nome do usuário
//       final String userName = provider.user['name'];

//       firstName = userName.split(' ').first;
//     }

//     return AppBar(
//       backgroundColor: AppColors.background,
//       title: SizedBox(
//           child: Flex(
//         direction: Axis.horizontal,
//         mainAxisAlignment: MainAxisAlignment.center,
//         children: [
//           //   define o logo no topo
//           Container(
//             width: 90,
//             margin:
//                 const EdgeInsets.only(top: 3, left: 0, right: 60, bottom: 3),
//             child: Image.asset('assets/images/logo_verde.png'),
//           )
//         ],
//       )),
//       actions: actions,
//       flexibleSpace: Padding(
//         padding: const EdgeInsets.only(left: 45.0, top: 55),
//         child: provider.user != null && hasBackButton == false
//             ? Align(
//                 alignment: Alignment.centerLeft,
//                 child: Text(
//                   'Olá, $firstName',
//                   style: const TextStyle(color: Colors.white, fontSize: 12),
//                 ),
//               )
//             : null,
//       ),
//       leading: Builder(
//         builder: (context) {
//           if (hasBackButton == true) {
//             return Flex(direction: Axis.horizontal, children: [
//               SizedBox(
//                   child: IconButton(
//                 icon: const Icon(
//                   Icons.arrow_back,
//                   color: AppColors.secundary,
//                 ),
//                 onPressed: () {
//                   redirectPage(context, const DashboardSys());
//                 },
//               )),
//             ]);
//           } else {
//             return Flex(direction: Axis.horizontal, children: [
//               SizedBox(
//                   child: IconButton(
//                 icon: const Icon(
//                   Icons.menu,
//                   color: AppColors.secundary,
//                 ),
//                 onPressed: () {
//                   Scaffold.of(context).openDrawer();
//                 },
//               )),
//             ]);
//           }
//         },
//       ),
//     );
//   }

//   @override
//   Size get preferredSize =>
//       const Size.fromHeight(kToolbarHeight); // Define a altura do AppBar
// }
