import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomDialog {
  static Future<void> show({
    required BuildContext context,
    required String title,
    required String content,
    String confirmText = 'Confirmar',
    VoidCallback? onConfirm,
    String btnTextActionLeft = 'Cancelar',
    VoidCallback? btnActionLeft,
  }) {
    final appColors = AppColors();

    return showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: appColors.backgroundGray2,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          title: Text(
            title,
            style: TextStyle(
                color: appColors.textWhite,
                fontWeight: FontWeight.bold,
                fontSize: 28),
          ),
          content: Text(
            content,
            style: TextStyle(color: appColors.textWhite, fontSize: 20),
          ),
          actions: <Widget>[
            if (btnActionLeft != null)
              TextButton(
                style: TextButton.styleFrom(
                  foregroundColor: appColors.textWhite,
                  backgroundColor: appColors.backgroundQuaternary,
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(5), // Bordas arredondadas
                  ),
                ),
                onPressed: () {
                  btnActionLeft();
                  Navigator.of(context).pop(); // Fecha o diálogo
                },
                child: Text(btnTextActionLeft),
              ),
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: appColors.textWhite,
                backgroundColor: appColors.backgroundQuaternary, // Cor do texto
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5), // Bordas arredondadas
                ),
              ),
              onPressed: () {
                if (onConfirm != null) {
                  onConfirm();
                }
                Navigator.of(context).pop(); // Fecha o diálogo
              },
              child: Text(confirmText),
            ),
          ],
        );
      },
    );
  }
}
