import 'package:vip_totem/shared/app_colors.dart';
import 'package:flutter/material.dart';

class CustomTextLink extends StatelessWidget {
  final String title;
  final VoidCallback action;

  const CustomTextLink({super.key, required this.title, required this.action});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return SizedBox(
        child: Center(
            child: GestureDetector(
      onTap: () {
        // ação ao clicar
        action();
      },
      child: Text(
        title,
        style: TextStyle(
          color: appColors.secundary,
          decoration: TextDecoration.underline,
        ),
      ),
    )));
  }
}
