import 'package:vip_totem/components/custom_drawer.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:flutter/material.dart';

class CustomScaffoldFlexible extends StatelessWidget {
  final String? title;
  final Widget body;
  final Widget? floatButton;

  const CustomScaffoldFlexible(
      {super.key, this.title, required this.body, this.floatButton});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Scaffold(
      backgroundColor: appColors.background,
      // appBar: const CustomAppBarLogo(),
      drawer: const CustomDrawer(),
      floatingActionButton: floatButton,
      body: body,
    );
  }
}
