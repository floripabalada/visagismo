// import 'package:vip_totem/config/app_colors.dart';
// import 'package:vip_totem/page/home/home_app.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:vip_totem/provider/auth_provider.dart';

// class MenuItem {
//   final String title;
//   final IconData icons;
//   final Widget mainPage;

//   MenuItem({required this.title, required this.icons, required this.mainPage});
// }

// class Menu extends ConsumerWidget {
//   const Menu({super.key});

//   @override
//   Widget build(BuildContext context, WidgetRef ref) {
//     // faz a leitura do provider
//     final provider = ref.watch(authProvider);

//     final List<MenuItem> menuItem = [
//       MenuItem(title: 'Home', icons: Icons.home, mainPage: const Home()),
//       MenuItem(
//           title: 'Produto SV3', icons: Icons.diamond, mainPage: const Home()),
//       MenuItem(
//           title: 'Atendente virtual',
//           icons: Icons.support_agent,
//           mainPage: const Home()),
//       MenuItem(
//           title: 'Plano', icons: Icons.emoji_events, mainPage: const Home()),
//     ];

//     return Column(
//         children: menuItem.map((item) {
//       return (ListTile(
//         leading: CircleAvatar(
//           backgroundColor: AppColors.iconBackgroundPrimary,
//           child: Icon(item.icons, color: AppColors.iconPrimary),
//         ),
//         title: Text(
//           item.title,
//           style: const TextStyle(color: AppColors.secundary, fontSize: 15),
//         ),
//         onTap: () {
//           Navigator.pushReplacement(
//               context, MaterialPageRoute(builder: (context) => item.mainPage));
//         },
//       ));
//     }).toList());
//   }
// }
