import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CustomProgressIndicator extends StatelessWidget {
  final double size;
  final Color? color;
  final double strokeWidth;

  const CustomProgressIndicator({
    super.key,
    this.size = 50.0,
    this.color,
    this.strokeWidth = 6.0,
  });

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    Color setColor = color ?? appColors.backgroundSecundary;

    return SizedBox(
      width: size,
      height: size,
      child: CircularProgressIndicator(
        valueColor: AlwaysStoppedAnimation(setColor), // Define a cor
        strokeWidth: strokeWidth,
        value: null,
        backgroundColor: Colors.grey[300],
      ),
    );
  }
}
