class ResponseModel {
  bool success;
  String message;
  dynamic data;

  ResponseModel({
    this.success = false,
    this.message = '',
    this.data,
  });

  dynamic getResponse() {
    return this;
  }
}
