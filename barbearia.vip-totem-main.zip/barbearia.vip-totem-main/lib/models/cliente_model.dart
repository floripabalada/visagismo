class ClientModel {
  final int id;
  final String nome;
  final String? cpf;
  final String? rg;
  final String telefone;
  final bool cadastroRestricaoAgendamento;
  final String? email;
  final String? convenio;
  final bool programaFidelidadeAderir;
  final String? programaFidelidadeUrl;
  dynamic history;
  dynamic balance;
  double pointsBalance;

  ClientModel(
      {required this.id,
      required this.nome,
      this.cpf,
      this.rg,
      required this.telefone,
      required this.cadastroRestricaoAgendamento,
      this.email,
      this.convenio,
      required this.programaFidelidadeAderir,
      required this.programaFidelidadeUrl,
      this.history,
      this.balance,
      this.pointsBalance = 0.0});

  factory ClientModel.fromJson(Map<String, dynamic> json) {
    return ClientModel(
      id: json['id'],
      nome: json['nome'],
      cpf: json['cpf'],
      rg: json['rg'],
      telefone: json['telefone'],
      cadastroRestricaoAgendamento: json['cadastro_restricao_agendamento'],
      email: json['email'],
      convenio: json['convenio'],
      programaFidelidadeAderir: json['programa_fidelidade_aderir'],
      programaFidelidadeUrl: json['programa_fidelidade_url'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nome': nome,
      'cpf': cpf,
      'rg': rg,
      'telefone': telefone,
      'cadastro_restricao_agendamento': cadastroRestricaoAgendamento,
      'email': email,
      'convenio': convenio,
      'programa_fidelidade_aderir': programaFidelidadeAderir,
      'programa_fidelidade_url': programaFidelidadeUrl,
      'history': history,
      'balance': balance,
      'pointsBalance': pointsBalance
    };
  }
}
