import 'package:logger/logger.dart';

class DLogger {
  static final Logger _logger = Logger();

  static Logger get show => _logger;
}
