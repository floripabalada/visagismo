import 'package:flutter/material.dart';

final configTheme = ThemeData(
  fontFamily: 'Din',
  textTheme: const TextTheme(
    bodyLarge: TextStyle(fontFamily: 'Din'),
    bodyMedium: TextStyle(fontFamily: 'Din'),
    bodySmall: TextStyle(fontFamily: 'Din'),
    headlineLarge: TextStyle(fontFamily: 'Din'),
    headlineMedium: TextStyle(fontFamily: 'Din'),
    headlineSmall: TextStyle(fontFamily: 'Din'),
    titleLarge: TextStyle(fontFamily: 'Din'),
    titleMedium: TextStyle(fontFamily: 'Din'),
    titleSmall: TextStyle(fontFamily: 'Din'),
    labelLarge: TextStyle(fontFamily: 'Din'),
    labelMedium: TextStyle(fontFamily: 'Din'),
    labelSmall: TextStyle(fontFamily: 'Din'),
  ),
);
