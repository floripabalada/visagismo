// validação de email
bool validateEmail(String email) {
  // Expressão regular para verificar o formato de um email
  const emailPattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$';
  final emailRegExp = RegExp(emailPattern);

  return emailRegExp.hasMatch(email);
}

// validação de telefone
bool validatePhoneNumber(String phone) {
  // Expressão regular para validar números de telefone no formato brasileiro
  const phonePattern = r'^\(?\d{2}\)?\s?\d{4,5}-?\d{4}$';
  final phoneRegExp = RegExp(phonePattern);

  return phoneRegExp.hasMatch(phone);
}

// validação de data
bool validateDate(String date) {
  // Verifica se a data tem o formato dd/mm/yyyy
  const datePattern = r'^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\d{4}$';
  final dateRegExp = RegExp(datePattern);

  if (!dateRegExp.hasMatch(date)) {
    return false; // Se o formato não for válido
  }

  // Tenta converter a string para um objeto DateTime
  final parts = date.split('/');
  final day = int.parse(parts[0]);
  final month = int.parse(parts[1]);
  final year = int.parse(parts[2]);

  // Verifica se a data é válida
  try {
    final dateTime = DateTime(year, month, day);
    return dateTime.day == day &&
        dateTime.month == month &&
        dateTime.year == year;
  } catch (e) {
    return false;
  }
}
