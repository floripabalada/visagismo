import 'package:flutter/material.dart';

Future<void> redirectPage(BuildContext context, Widget page,
    {String type = 'push'}) async {
  // Aguarda um pequeno delay ou qualquer operação assíncrona que você tenha
  await Future.delayed(const Duration(milliseconds: 100));

  // Verifica se o widget ainda está montado antes de tentar navegar
  if (context.mounted) {
    if (type == 'push') {
      Navigator.of(context).push(
        MaterialPageRoute(
          builder: (BuildContext context) => page,
        ),
      );
    } else if (type == 'pushReplacement') {
      debugPrint('pushReplacement');
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => page,
        ),
      );
    } else if (type == 'clearStack') {
      // Remove todas as telas anteriores e vai para a página inicial
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => page),
        // remove todas da pilha e seta o menu como principal
        ModalRoute.withName('/'),
      );
    }
  }
}
