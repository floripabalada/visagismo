// normaliza o cpf para consulta no banco
import 'package:device_info_plus/device_info_plus.dart';
import 'dart:io';

String normalizeCpf(cpf) {
  return (cpf).replaceAll(".", "").replaceAll("-", "");
}

String formatPhoneNumber(String phone) {
  if (phone.isEmpty) return phone;

  // Remove todos os caracteres não numéricos
  phone = phone.replaceAll(RegExp(r'\D'), '');

  // Verifica se o número tem tamanho suficiente (com ou sem DDD)
  if (phone.length == 10) {
    // Formato: (XX) XXXX-XXXX
    return '(${phone.substring(0, 2)}) ${phone.substring(2, 6)}-${phone.substring(6)}';
  } else if (phone.length == 11) {
    // Formato: (XX) XXXXX-XXXX (com 9 dígitos)
    return '(${phone.substring(0, 2)}) ${phone.substring(2, 7)}-${phone.substring(7)}';
  } else {
    // Caso o número não seja válido
    return phone;
  }
}

// retorna os dados do sistema
Future<Map> getOsInfo() async {
  // retorna os dados do device
  final deviceInfoPlugin = DeviceInfoPlugin();

  Map data = {"operatingSystem": "", "systemVersion": "", "deviceModel": ""};

  if (Platform.isAndroid) {
    // Informações sobre Android
    final androidInfo = await deviceInfoPlugin.androidInfo;

    data['operatingSystem'] = "Android";
    data['systemVersion'] = androidInfo.version.release;
    data['deviceModel'] = androidInfo.model;
  } else if (Platform.isIOS) {
    // Informações sobre iOS
    final iosInfo = await deviceInfoPlugin.iosInfo;

    data['operatingSystem'] = "iOS";
    data['systemVersion'] = iosInfo.systemVersion;
    data['deviceModel'] = iosInfo.utsname.machine;
  }

  return data;
}
