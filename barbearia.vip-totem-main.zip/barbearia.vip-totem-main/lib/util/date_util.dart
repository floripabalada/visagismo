import 'package:intl/intl.dart';

class DateUtil {
  static Map<String, String> formatDateForAllTypes(String dateString) {
    // faz o parse de string para date
    DateTime date = DateFormat('dd/MM/yyyy HH:mm:ss').parse(dateString);

    // monta os dados de retorno
    return {
      'date': DateFormat('dd/MM/yyyy').format(date),
      'hour': DateFormat('HH:mm').format(date),
      'day': DateFormat('dd').format(date),
      'month': DateFormat('MMM').format(date).toUpperCase(),
      'year': DateFormat('yyyy').format(date)
    };
  }
}
