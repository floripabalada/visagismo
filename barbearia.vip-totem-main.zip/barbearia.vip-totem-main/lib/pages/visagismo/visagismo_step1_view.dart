import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_radio_button.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/visagismo/component/progress_bar_component.dart';
import 'package:vip_totem/pages/visagismo/component/question_display_component.dart';
import 'package:vip_totem/pages/visagismo/component/top_bar_component.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step2_view.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';
import 'package:vip_totem/util/route_util.dart';

class VisagismoStep1View extends ConsumerStatefulWidget {
  const VisagismoStep1View({super.key});

  @override
  VisagismoStep1ViewState createState() => VisagismoStep1ViewState();
}

class VisagismoStep1ViewState extends ConsumerState<VisagismoStep1View> {
  String selectedValue = '';
  String labelFirstName = '';

  @override
  void initState() {
    super.initState();
    // ao carregar consulta os dados do provider
    loadStepData();
  }

  // Função para buscar o dado salvo
  Future<void> loadStepData() async {
    final visagismoNotifier = ref.read(visagismoProvider.notifier);
    final refAuthProvider = ref.read(authProvider);

    // consulta os dados do primeiro passo
    final result = await visagismoNotifier.fetchStep('qt1');

    // consuta os dados do cliente
    dynamic responseUser = await refAuthProvider.user;

    if (mounted) {
      setState(() {
        selectedValue = result ?? '';
        labelFirstName = responseUser['primeiro_nome'] ?? '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    final visagismoNotifier = ref.read(visagismoProvider.notifier);

    return Scaffold(
      backgroundColor: appColors.background,
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Padding(
            padding:
                const EdgeInsets.only(left: 75, right: 75, top: 30, bottom: 30),
            child: Column(
              children: [
                Expanded(
                  child: Column(children: [
                    TopBarComponent(icon: Icons.close, onPressed: () => {}),
                    const SizedBox(height: 10),
                    const ProgressBarComponent(totalSteps: 8, currentStep: 1),
                  ]),
                ),
                Expanded(
                  flex: 1,
                  child: QuestionDisplayComponent(
                    image:
                        'assets/images/ilustrations/undraw_lightbulb_moment_c8jn.svg',
                    question:
                        "$labelFirstName, qual a imagem que você gostaria de transmitir com seu estilo de cabelo e barba?",
                    description:
                        'Seja a sua melhor versão, agora é agora de melhora ainda mais...',
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Center(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CustomRadioButton(
                          options: [
                            Option(id: 'Confiança', description: 'Confiança'),
                            Option(
                                id: 'Criatividade',
                                description: 'Criatividade'),
                            Option(
                                id: 'Formalidade', description: 'Formalidade'),
                            Option(
                                id: 'Descontração',
                                description: 'Descontração'),
                            Option(
                                id: 'Sofisticação',
                                description: 'Sofisticação'),
                            Option(
                                id: 'Modernidade', description: 'Modernidade'),
                          ],
                          optionSelected: selectedValue,
                          onOptionSelected: (optionSelected) {
                            // informa qual item foi selecionado
                            setState(() {
                              selectedValue = optionSelected;
                            });

                            // atualiza o provider
                            visagismoNotifier.saveStep('qt1', optionSelected);

                            // direciona para o próximo passo
                            redirectPage(context, const VisagismoStep2View());
                          },
                        ),
                      ],
                    ),
                  ),
                ),
                const CustomImage(
                  imagePath: 'assets/images/logo_verde.png',
                  width: 80,
                  height: 80,
                  type: 'png',
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
