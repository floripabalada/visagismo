import 'dart:typed_data';
import 'package:camera/camera.dart';
// import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
// import 'package:image_picker/image_picker.dart';
import 'package:vip_totem/components/custom_button.dart';
import 'package:vip_totem/components/custom_button_icon.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_scaffold_messenger.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/visagismo/component/progress_bar_component.dart';
import 'package:vip_totem/pages/visagismo/component/question_display_component.dart';
import 'package:vip_totem/pages/visagismo/component/top_bar_component.dart';
import 'package:vip_totem/pages/visagismo/visagismo_process_view.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step5_view.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/util/route_util.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';

import 'package:camera_macos/camera_macos.dart';

class VisagismoPhotoCaptureView extends ConsumerStatefulWidget {
  const VisagismoPhotoCaptureView({super.key});

  @override
  VisagismoPhotoCaptureViewState createState() =>
      VisagismoPhotoCaptureViewState();
}

class VisagismoPhotoCaptureViewState
    extends ConsumerState<VisagismoPhotoCaptureView> {
  final GlobalKey cameraKey = GlobalKey();
  Uint8List? imageBytes = Uint8List(0);
  ValueNotifier<String> labelCounter = ValueNotifier<String>("");
// vip456barber
  // macOS
  late CameraMacOSController macOSController;
  CameraController? controller;
  Future<void>? initializeControllerFuture;

  Future<void> setupCamera() async {
    try {
      // instancia as cameras disponíveis
      final cameras = await availableCameras();

      if (!mounted) return;

      final canController = CameraController(
        cameras.first,
        ResolutionPreset.high,
      );

      // inicializa a camera
      initializeControllerFuture = canController.initialize();
      await initializeControllerFuture;

      if (mounted) {
        setState(() {
          controller = canController;
          initializeControllerFuture = Future.value();
        });
      }
    } catch (e, stack) {
      debugPrint('Erro ao configurar câmera: $e');
      debugPrint('$stack');
    }
  }

  Future<void> shotCounter() async {
    for (int i = 3; i >= 1; i--) {
      labelCounter.value = "$i";
      await Future.delayed(const Duration(seconds: 1));
    }
    labelCounter.value = "";
  }

  @override
  void initState() {
    super.initState();
    setupCamera();
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    final refVisagismoProvider = ref.read(visagismoProvider.notifier);
    final labelFirstName = ref.read(authProvider).user['primeiro_nome'];

    imageBytes = refVisagismoProvider.fetchStep('image');

    return Scaffold(
      backgroundColor: appColors.background,
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 75, vertical: 30),
            child: Column(
              children: [
                Expanded(
                  child: Column(
                    children: [
                      TopBarComponent(icon: Icons.close, onPressed: () => {}),
                      const SizedBox(height: 10),
                      const ProgressBarComponent(totalSteps: 8, currentStep: 6)
                    ],
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: QuestionDisplayComponent(
                    question:
                        "$labelFirstName está quase! Tire uma foto do seu rosto.",
                  ),
                ),
                Expanded(
                  flex: 4,
                  child: Center(
                    child: Stack(
                      children: [
                        if (imageBytes!.isEmpty)
                          Stack(
                            children: [
                              Text(imageBytes.toString()),
                              // if (Platform.isMacOS)
                              //   CameraMacOSView(
                              //     key: cameraKey,
                              //     orientation:
                              //         CameraOrientation.orientation0deg,
                              //     resolution: PictureResolution.medium,
                              //     cameraMode: CameraMacOSMode.photo,
                              //     onCameraInizialized:
                              //         (CameraMacOSController controller) {
                              //       setState(() {
                              //         macOSController = controller;
                              //       });
                              //     },
                              //   ),
                              if (controller != null &&
                                  controller!.value.isInitialized)
                                Center(
                                  child: AspectRatio(
                                    aspectRatio: controller!.value.aspectRatio,
                                    child: CameraPreview(controller!),
                                  ),
                                )
                              else if (imageBytes!.isEmpty)
                                const Center(
                                    child: CircularProgressIndicator()),
                              // contagem para tirar foto
                              ValueListenableBuilder(
                                valueListenable: labelCounter,
                                builder: (_, value, __) => Center(
                                  child: Text(
                                    value,
                                    style: const TextStyle(
                                      fontSize: 150,
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              )
                            ],
                          ),
                        if (imageBytes!.isNotEmpty)
                          Image.memory(
                            imageBytes!,
                            fit: BoxFit.cover,
                          ),
                      ],
                    ),
                  ),
                ),
                if (imageBytes!.isNotEmpty)
                  CustomButtonIcon(
                    icon: Icons.delete,
                    size: 100,
                    color: appColors.backGroundRed,
                    onPressed: () {
                      setState(() {
                        imageBytes = Uint8List(0);
                      });
                      // atualiza o provider
                      refVisagismoProvider.saveStep('image', Uint8List(0));
                    },
                  )
                else
                  CustomButtonIcon(
                      icon: Icons.camera_alt,
                      size: 100,
                      onPressed: () async {
                        await shotCounter();
                        // if (macOSController != null) {
                        //   final picture = await macOSController.takePicture();
                        //   if (picture != null) {
                        //     final bytes = await picture.bytes;
                        //     setState(() {
                        //       imageBytes = bytes;
                        //     });
                        //     refVisagismoProvider.saveStep('image', bytes);
                        //   }
                        // }
                        if (controller != null &&
                            controller!.value.isInitialized) {
                          try {
                            final picture = await controller!.takePicture();
                            final bytes = await picture.readAsBytes();

                            await controller!.initialize();

                            setState(() {
                              imageBytes = bytes;
                            });

                            refVisagismoProvider.saveStep('image', bytes);
                          } catch (e) {
                            debugPrint("Erro ao tirar foto: $e");
                          }
                        }
                      }),
                const SizedBox(height: 40),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    SizedBox(
                      width: 300,
                      child: CustomButton(
                        onPressed: () =>
                            redirectPage(context, const VisagismoStep5View()),
                        icon: Icons.navigate_before,
                        positionIcon: 'after',
                        backgroundColor: appColors.backgroundGray,
                        textColor: appColors.textGrey,
                        iconColor: appColors.textGrey,
                        text: 'Voltar',
                      ),
                    ),
                    const SizedBox(width: 20),
                    SizedBox(
                      width: 300,
                      child: CustomButton(
                        onPressed: () {
                          imageBytes!.isNotEmpty
                              ? redirectPage(
                                  context, const VisagismoProcessView())
                              : CustomScaffoldMessenger(context: context).show(
                                  message:
                                      'Por favor, tire uma foto do seu rosto.');
                        },
                        icon: Icons.navigate_next,
                        text: 'Continuar',
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                const CustomImage(
                  imagePath: 'assets/images/logo_verde.png',
                  width: 80,
                  height: 80,
                  type: 'png',
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
