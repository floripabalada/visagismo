import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_button.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_radio_button.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/visagismo/component/progress_bar_component.dart';
import 'package:vip_totem/pages/visagismo/component/question_display_component.dart';
import 'package:vip_totem/pages/visagismo/component/top_bar_component.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step2_view.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step4_view.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';
import 'package:vip_totem/util/route_util.dart';

class VisagismoStep3View extends ConsumerStatefulWidget {
  const VisagismoStep3View({
    super.key,
  });
  @override
  VisagismoStep3ViewState createState() => VisagismoStep3ViewState();
}

class VisagismoStep3ViewState extends ConsumerState<VisagismoStep3View> {
  String selectedValue = '';

  @override
  void initState() {
    super.initState();
    // ao carregar consulta os dados do provider
    loadStepData();
  }

  // Função para buscar o dado salvo
  Future<void> loadStepData() async {
    final visagismoNotifier = ref.read(visagismoProvider.notifier);
    final result = await visagismoNotifier.fetchStep('qt3');

    if (mounted) {
      setState(() {
        selectedValue = result ?? '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    final visagismoNotifier = ref.read(visagismoProvider.notifier);

    return Scaffold(
        backgroundColor: appColors.background,
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 30, bottom: 30),
              child: Column(
                children: [
                  Expanded(
                      child: Column(children: [
                    TopBarComponent(
                      icon: Icons.close,
                      onPressed: () => {},
                    ),
                    const SizedBox(height: 10),
                    const ProgressBarComponent(totalSteps: 8, currentStep: 3)
                  ])),
                  const Expanded(
                      flex: 1,
                      child: QuestionDisplayComponent(
                          image:
                              'assets/images/ilustrations/undraw_businessman_8vs7-2.svg',
                          question:
                              'Qual seu estilo de vida e rotina diária?')),
                  Expanded(
                      flex: 4,
                      child: Center(
                        child:
                            Column(mainAxisSize: MainAxisSize.min, children: [
                          CustomRadioButton(
                              options: [
                                Option(
                                    id: 'Estilo de vida ativo (exercícios)',
                                    description:
                                        'Estilo de vida ativo (exercícios)'),
                                Option(
                                    id:
                                        'Estilo de vida profissional (muito tempo no escritório)',
                                    description:
                                        'Estilo de vida profissional (muito tempo no escritório)'),
                                Option(
                                    id:
                                        'Estilo de vida social (muitas saídas e eventos)',
                                    description:
                                        'Estilo de vida social (muitas saídas e eventos)'),
                                Option(
                                    id:
                                        'Estilo de vida tranquilo (mais tempo em casa)',
                                    description:
                                        'Estilo de vida tranquilo (mais tempo em casa)'),
                              ],
                              optionSelected: selectedValue,
                              onOptionSelected: (optionSelected) {
                                // informa qual item foi selecionado
                                setState(() {
                                  selectedValue = optionSelected;
                                });

                                // atualiza o provider
                                visagismoNotifier.saveStep(
                                    'qt3', optionSelected);

                                // print(optionSelected)
                                redirectPage(
                                    context, const VisagismoStep4View());
                              })
                        ]),
                      )),
                  SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                              width: 200,
                              child: CustomButton(
                                  onPressed: () => {
                                        redirectPage(
                                            context, const VisagismoStep2View())
                                      },
                                  icon: Icons.navigate_before,
                                  positionIcon: 'after',
                                  backgroundColor: appColors.backgroundGray,
                                  textColor: appColors.textGrey,
                                  iconColor: appColors.textGrey,
                                  text: 'Voltar')),
                          const SizedBox(
                            width: 20,
                          ),
                        ],
                      )),
                  const SizedBox(width: 16),
                  const CustomImage(
                    imagePath: 'assets/images/logo_verde.png',
                    width: 80,
                    height: 80,
                    type: 'png',
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
