import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

class VisagismoVideoView extends StatefulWidget {
  @override
  VisagismoVideoViewState createState() => VisagismoVideoViewState();
}

class VisagismoVideoViewState extends State<VisagismoVideoView> {
  late VideoPlayerController _controller;

  @override
  void initState() {
    super.initState();

    // Inicializando o controlador de vídeo
    _controller = VideoPlayerController.asset(
        'assets/videos/malvino_salvado_instutucional.mp4')
      ..initialize().then((_) {
        setState(() {});
      })
      ..setLooping(true) // Define o vídeo para rodar em loop
      ..play(); // Inicia o vídeo assim que estiver pronto
  }

  @override
  void dispose() {
    super.dispose();
    _controller.dispose(); // Libera os recursos quando o widget for destruído
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: _controller.value.isInitialized
            ? Column(children: [
                // const Expanded(
                //   flex: 1,
                //   child: CustomImage(
                //     imagePath: 'assets/images/logo_verde.png',
                //     width: 300,
                //     // height: 300,
                //   ),
                // ),
                Expanded(
                    flex: 2,
                    child: AspectRatio(
                      aspectRatio: _controller.value.aspectRatio,
                      child: VideoPlayer(_controller),
                    )),
                // Expanded(
                //   // flex: 1,
                //   child: Align(
                //     alignment: Alignment.center, // Para centralizar o botão
                //     child: SizedBox(
                //       height: 80, // Defina a altura fixa do botão
                //       width: 500, // Largura fixa
                //       child: CustomButton(
                //         onPressed: () {
                //           redirectPage(context, const MenuApp());
                //         },
                //         icon: Icons.navigate_next,
                //         text: 'Clique para inciar',
                //       ),
                //     ),
                //   ),
                // ),
              ])
            : const CircularProgressIndicator(),
      ),
    );
  }
}
