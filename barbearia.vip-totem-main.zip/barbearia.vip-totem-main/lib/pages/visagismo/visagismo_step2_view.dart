import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_button.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_radio_button.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/visagismo/component/progress_bar_component.dart';
import 'package:vip_totem/pages/visagismo/component/question_display_component.dart';
import 'package:vip_totem/pages/visagismo/component/top_bar_component.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step1_view.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step3_view.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';
import 'package:vip_totem/util/route_util.dart';

class VisagismoStep2View extends ConsumerStatefulWidget {
  const VisagismoStep2View({
    super.key,
  });
  @override
  VisagismoStep2ViewState createState() => VisagismoStep2ViewState();
}

class VisagismoStep2ViewState extends ConsumerState<VisagismoStep2View> {
  String selectedValue = '';

  @override
  void initState() {
    super.initState();
    // ao carregar consulta os dados do provider
    loadStepData();
  }

  // Função para buscar o dado salvo
  Future<void> loadStepData() async {
    final visagismoNotifier = ref.read(visagismoProvider.notifier);
    final result = await visagismoNotifier.fetchStep('qt2');

    if (mounted) {
      setState(() {
        selectedValue = result ?? '';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    final visagismoNotifier = ref.read(visagismoProvider.notifier);

    return Scaffold(
        backgroundColor: appColors.background,
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 30, bottom: 30),
              child: Column(
                children: [
                  Expanded(
                      child: Column(children: [
                    TopBarComponent(
                      icon: Icons.close,
                      onPressed: () => {},
                    ),
                    const SizedBox(height: 10),
                    const ProgressBarComponent(totalSteps: 8, currentStep: 2)
                  ])),
                  const Expanded(
                      flex: 1,
                      child: QuestionDisplayComponent(
                          image:
                              'assets/images/ilustrations/undraw_pic-profile_nr49.svg',
                          question:
                              'Tem algum aspecto do seu rosto ou cabelo que você gostaria de realçar ou camuflar?')),
                  Expanded(
                      flex: 4,
                      child: Center(
                        child:
                            Column(mainAxisSize: MainAxisSize.min, children: [
                          CustomRadioButton(
                              options: [
                                Option(id: 'Realçar', description: 'Realçar'),
                                Option(
                                    id: 'Entradas de cabelo',
                                    description: 'Entradas de cabelo'),
                                Option(
                                    id: 'Camuflar testa',
                                    description: 'Camuflar testa'),
                                Option(
                                    id: 'Camuflar bochechas',
                                    description: 'Camuflar bochechas'),
                                Option(
                                    id: 'Realçar olhos',
                                    description: 'Realçar olhos'),
                                Option(
                                    id: 'Camuflar clavice topo',
                                    description: 'Camuflar clavice topo'),
                              ],
                              optionSelected: selectedValue,
                              onOptionSelected: (optionSelected) {
                                // informa qual item foi selecionado
                                setState(() {
                                  selectedValue = optionSelected;
                                });

                                // atualiza o provider
                                visagismoNotifier.saveStep(
                                    'qt2', optionSelected);

                                // redireciona para o próximo passao
                                redirectPage(
                                    context, const VisagismoStep3View());
                              })
                        ]),
                      )),
                  SizedBox(
                      width: double.infinity,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          SizedBox(
                              width: 200,
                              child: CustomButton(
                                  onPressed: () => {
                                        redirectPage(
                                            context, const VisagismoStep1View())
                                      },
                                  icon: Icons.navigate_before,
                                  positionIcon: 'after',
                                  backgroundColor: appColors.backgroundGray,
                                  textColor: appColors.textGrey,
                                  iconColor: appColors.textGrey,
                                  text: 'Voltar')),
                          const SizedBox(
                            width: 20,
                          ),
                          // SizedBox(
                          //     width: 300,
                          //     child: CustomButton(
                          //         onPressed: () {
                          //           if (selectedValue.isNotEmpty) {
                          //             // direciona para o próximo passo
                          //             redirectPage(
                          //                 context, const VisagismoStep3());
                          //           } else {
                          //             CustomScaffoldMessenger.show(context,
                          //                 'Por favor, selecione uma opção');
                          //           }
                          //         },
                          //         icon: Icons.navigate_next,
                          //         text: 'Continuar'))
                        ],
                      )),
                  const SizedBox(width: 16),
                  const CustomImage(
                    imagePath: 'assets/images/logo_verde.png',
                    width: 80,
                    height: 80,
                    type: 'png',
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
