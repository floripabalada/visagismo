import 'dart:convert';
import 'dart:typed_data';
import 'package:image/image.dart' as img;
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_progress_indicator.dart';
import 'package:vip_totem/components/custom_rotating_text.dart';
import 'package:vip_totem/components/custom_scaffold_messenger.dart';
import 'package:vip_totem/config/environment.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/visagismo/component/progress_bar_component.dart';
import 'package:vip_totem/pages/visagismo/component/top_bar_component.dart';
import 'package:vip_totem/pages/visagismo/visagismo_photo_capture_view.dart';
import 'package:vip_totem/pages/visagismo/visagismo_result_view.dart';
import 'package:vip_totem/util/route_util.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';
import 'package:http_parser/http_parser.dart';

class VisagismoProcessView extends ConsumerStatefulWidget {
  const VisagismoProcessView({
    super.key,
  });
  @override
  VisagismoProcessViewState createState() => VisagismoProcessViewState();
}

class VisagismoProcessViewState extends ConsumerState<VisagismoProcessView> {
  String urlApi = "https://www.franquiabv.com.br/api/visagismo";
  String tokenApi = "W4TVJhUUUVsbz46ubVRJTFcwTlwZUGsh";

  dynamic data;
  String labelProcess = 'Processando imagem...';

  @override
  void initState() {
    super.initState();
    // ao carregar consulta os dados do provider
    processData();
  }

  // Função para buscar o dado salvo
  Future<void> processData() async {
    final notifier = CustomScaffoldMessenger(context: context);
    bool success = true;

    final refAuthProvider = ref.read(authProvider);
    final refVisagismoProvider = ref.read(visagismoProvider.notifier);
    final dataVisagismoProvider = refVisagismoProvider.fetchAllData();

    final client = refAuthProvider.user;

    try {
      //  faz o upload da imagem
      final responseUploadImage =
          await uploadImage(dataVisagismoProvider['image']);

      if (responseUploadImage['sucesso'] == false) {
        throw Exception('Erro upload de imagem');
      }

      setState(() {
        labelProcess = 'Analisando foto e dados...';
      });

      final imageId = responseUploadImage['id'];
      final imageUrl = responseUploadImage['url'];
      final imageFile = responseUploadImage['arquivo'];

      setState(() {
        labelProcess = 'Mapeando seu rosto...';
      });

      // gera imagem com mapeamento do rosto
      final responseFaceMapping =
          await faceMapping(imageId, imageUrl, imageFile);

      if (responseFaceMapping['sucesso'] == false) {
        throw Exception('Erro ao mapear rosto');
      }

      setState(() {
        labelProcess = 'Realizando análise dos dados';
      });

      // faz o processamento de IA
      dynamic responseProcessIA = await processIA(responseUploadImage['id'],
          responseUploadImage['url'], dataVisagismoProvider, client);

      setState(() {
        labelProcess = 'Enviando cópia para WhatsApp';
      });

      // faz o envio para o WhatsApp
      await sendWhatsApp(client, responseProcessIA['pdf_url'] ?? '');

      setState(() {
        labelProcess = 'Processamento concluído.';
      });

      // realiza a análise de I.A
      if (responseProcessIA['sucesso'] == false) {
        throw Exception('Erro ao processar análise de I.A');
      }

      // seta os dados de retorno no provider
      refVisagismoProvider.saveStep('result', responseProcessIA['resultado']);
    } catch (error) {
      success = false;
    }

    if (success == false) {
      notifier.show(message: 'Opss... erro ao processar, tente novamente.');

      // ignore: use_build_context_synchronously
      redirectPage(context, const VisagismoPhotoCaptureView());
    } else {
      // ignore: use_build_context_synchronously
      redirectPage(context, const VisagismoResultView());
    }
  }

  Future<dynamic> uploadImage(Uint8List imageBytes) async {
    // faz a conversão para uma imagem jpeg válida
    img.Image? image = img.decodeImage(imageBytes);

    if (image != null) {
      imageBytes = img.encodeJpg(image, quality: 100);
    }

    final url = Uri.parse('$urlApi/foto-upload?token=$tokenApi');

    // cria o arquivo multipart da imagem em bytes
    var file = http.MultipartFile.fromBytes(
      'foto_rosto_arquivo',
      imageBytes,
      filename: "imagem_totem.jpg",
      contentType: MediaType.parse('image/jpeg'),
    );

    // prepara o request
    var request = http.MultipartRequest('POST', url)..files.add(file);

    request.headers.addAll({
      "Content-Type": "multipart/form-data",
    });

    // envia a requisição
    var response = await request.send();

    // Verificando o status da resposta
    if (response.statusCode == 200) {
      // retorno da api
      return jsonDecode(await response.stream.bytesToString());
    } else {
      // retorna sucesso e mesagem para menter retorno igual api
      return {'sucesso': false};
    }
  }

  Future<dynamic> faceMapping(id, url, file) async {
    // mapeamento do rosto
    var request = http.MultipartRequest(
      'POST',
      Uri.parse('$urlApi/foto-processar?token=$tokenApi'),
    );

    // Adicionando campos ao formulário
    request.fields['foto_rosto_url'] = url;
    request.fields['id'] = id.toString();
    request.fields['foto_rosto_arquivo_nome'] = file;

    // envia os dados
    final response = await request.send();

    // Verificando o status da resposta
    if (response.statusCode == 200) {
      // retorno da api
      return jsonDecode(await response.stream.bytesToString());
    } else {
      return {'sucesso': false};
    }
  }

  Future<dynamic> processIA(id, url, data, client) async {
    // monta o corpo da requisição
    Map<String, String> body = {
      'foto_rosto_url': url,
      'id': id.toString(),
      'telefone': client['telefone'],
      'nome': client['nome'].split(' ')[0],
      'resposta_0': data['qt1'].toString(),
      'resposta_1': data['qt2'].toString(),
      'resposta_2': data['qt3'].toString(),
      'resposta_3': data['qt4'].toString(),
      'resposta_4': data['qt5'].toString(),
    };

    final response = await http.post(
      Uri.parse('$urlApi/dados-processar?token=$tokenApi'),
      body: body,
    );

    // Verificando o status da resposta
    if (response.statusCode == 200) {
      // retorno da api
      return jsonDecode(response.body);
    } else {
      return {'sucesso': false};
    }
  }

  Future<void> sendWhatsApp(client, baseUrlPdf) async {
    // remove todos caracteres especiais
    String phone = client['telefone'].replaceAll(RegExp(r'\D'), '');
    // remove o DDI e depois adiciona na solicitação
    String phoneDDI =
        phone.startsWith('55') ? '55${phone.substring(2)}' : '55$phone';

    // primeira mensagem
    String message = ""
        "Olá ${client['nome'].split(' ')[0]}!\n"
        "Você acabou de fazer sua consultoria de visagismo com a IA da Barbearia VIP – e o resultado ficou incrível! 😎✨\n\n"
        "📎 Abaixo está o seu PDF personalizado com sugestões que combinam com o seu estilo e personalidade.\n"
        "Mostre pro seu barbeiro e prepare-se pra sair ainda mais confiante. Você merece isso – você merece ser VIP. 💛\n\n"
        "Ah, e se ainda não tem o nosso app, corre lá na loja de aplicativos e baixe o App Barbearia VIP.\n"
        "Tem descontos, promoções e vantagens que só os VIPs de verdade aproveitam. 😉";

    // monta a url do PlugZapi
    String baseUrl =
        "${Environment.plugZapiUrl}/instances/${Environment.plugZapiIdInstance}/token/${Environment.plugZapiToken}";
    String baseUrlSendText = "$baseUrl/send-text";
    String baseUrlSendDocument = "$baseUrl/send-document/pdf";

    dynamic header = {
      'Client-Token': Environment.plugzapiClientToken,
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    // envia a solicitação via post
    final response = await http.post(
      Uri.parse(baseUrlSendText),
      headers: header,
      body: {
        'phone': phoneDDI,
        'message': message,
      },
    );

    // Verificando o status da resposta
    if (response.statusCode == 200) {
      // resultado
      final result = jsonDecode(response.body);

      if (result.containsKey('messageId') && result['messageId'] != null) {
        // envia o documento pdf do visagismo
        await http.post(
          Uri.parse(baseUrlSendDocument),
          headers: header,
          body: {
            'phone': phoneDDI,
            'document': baseUrlPdf,
            'fileName': 'visagismo-barbearia-vip'
          },
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Scaffold(
        backgroundColor: appColors.background,
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 30, bottom: 30),
              child: Column(
                children: [
                  const Expanded(
                      child: Column(children: [
                    TopBarComponent(
                      icon: Icons.close,
                    ),
                    SizedBox(height: 10),
                    ProgressBarComponent(totalSteps: 8, currentStep: 7)
                  ])),
                  Expanded(
                      flex: 5,
                      child: Column(
                        children: [
                          const CustomImage(
                            imagePath:
                                'assets/images/ilustrations/undraw_barber_utly1.svg',
                            width: 500,
                            type: 'svg',
                          ),
                          const SizedBox(height: 50),
                          CustomRotatingText(
                              texts: const [
                                "Você está na maior rede de barberias da América Latina",
                                "Pioneira no conceito de 'barbearia premium'",
                                "Já baixou nosso App?"
                              ],
                              secondsExchange: 950,
                              seconds: 4,
                              style: TextStyle(
                                  fontSize: 20,
                                  color: appColors.iconPrimary,
                                  fontWeight: FontWeight.bold)),
                          Text('Estamos processando seus dados...',
                              style: TextStyle(
                                  fontSize: 28, color: appColors.textPrimary)),
                          const SizedBox(height: 50),
                          const CustomProgressIndicator(
                            size: 80,
                          ),
                          const SizedBox(height: 20),
                          Text(labelProcess,
                              style: TextStyle(
                                  fontSize: 15, color: appColors.textGrey)),
                        ],
                      )),
                  const CustomImage(
                    imagePath: 'assets/images/logo_verde.png',
                    width: 80,
                    height: 80,
                    type: 'png',
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
