import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class ProgressBarComponent extends StatelessWidget {
  final double totalSteps;
  final double currentStep;

  const ProgressBarComponent({
    super.key,
    required this.totalSteps,
    required this.currentStep,
  });

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    double percentual = (totalSteps > 0) ? (currentStep / totalSteps) : 0;

    return LayoutBuilder(
      builder: (context, constraints) {
        double maxWidth =
            constraints.maxWidth; // Captura a largura total disponível

        return Stack(
          children: [
            Container(
              height: 5,
              width: maxWidth,
              decoration: BoxDecoration(
                color: appColors.backgroundGray,
                borderRadius: BorderRadius.circular(5),
              ),
            ),
            TweenAnimationBuilder<double>(
              tween: Tween<double>(begin: 0, end: percentual),
              duration: const Duration(milliseconds: 1100), // Animação suave
              curve: Curves.easeInOut,
              builder: (context, animatedPercentual, child) {
                return Container(
                  height: 5,
                  width: (animatedPercentual * maxWidth),
                  decoration: BoxDecoration(
                    color: appColors.textYellow,
                    borderRadius: BorderRadius.circular(5),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }
}
