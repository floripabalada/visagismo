import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_dialog.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/menu/menu_view.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/util/route_util.dart';

class TopBarComponent extends ConsumerWidget {
  final Function()? onPressed;
  final IconData icon;
  final bool isDialog;

  const TopBarComponent(
      {super.key, this.onPressed, required this.icon, this.isDialog = true});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final appColors = AppColors();

    final firstName = ref.read(authProvider).user['primeiro_nome'];

    return Column(
      children: [
        Row(
          children: [
            const Expanded(flex: 1, child: SizedBox()),
            const Expanded(flex: 2, child: SizedBox()),
            Expanded(
              flex: 1,
              child: SizedBox(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    IconButton(
                      onPressed: () {
                        if (isDialog) {
                          CustomDialog.show(
                            context: context,
                            title: "Tem certeza $firstName?",
                            content:
                                'Vai fechar a consultoria de Visagismo agora?',
                            confirmText: 'Sim',
                            onConfirm: () {
                              redirectPage(context, const MenuView());
                            },
                            btnTextActionLeft: 'Não',
                            btnActionLeft: () => {},
                          );
                        } else {
                          redirectPage(context, const MenuView());
                        }
                      },
                      icon: Icon(icon),
                      iconSize: 40,
                      color: appColors.textPrimary,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
