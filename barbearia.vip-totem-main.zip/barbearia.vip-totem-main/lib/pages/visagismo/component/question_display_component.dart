import 'package:flutter/material.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/shared/app_colors.dart';

class QuestionDisplayComponent extends StatelessWidget {
  final String? image;
  final String? question;
  final String? description;

  const QuestionDisplayComponent(
      {super.key, this.image = '', this.question = '', this.description = ''});

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Container(
      decoration: BoxDecoration(
        color: appColors.backgroundSecundary,
        borderRadius: const BorderRadius.all(Radius.circular(20)),
        boxShadow: [
          BoxShadow(
            color: appColors.backgroundQuaternary,
            blurRadius: 10,
            offset: const Offset(0, 0),
            spreadRadius: 1,
          ),
        ],
      ),
      padding: const EdgeInsets.only(right: 10, top: 10, bottom: 0),
      child: Row(
        children: [
          // Exibe a imagem
          const CustomImage(
            imagePath: 'assets/images/malvino.png',
            width: 110,
          ),

          // Expande para o texto que será ajustado
          if (question != null && question!.isNotEmpty)
            Expanded(
              flex: 5,
              child: Container(
                padding: const EdgeInsets.only(left: 16),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Título principal
                    Text(
                      question!,
                      style: TextStyle(
                        fontSize: 26,
                        color: appColors.textWhite,
                      ),
                    ),
                    // Verifica se a descrição não é nula nem vazia
                    if (description != null && description!.isNotEmpty)
                      const SizedBox(
                        height: 8,
                      ), // Espaço entre o título e o subtítulo
                    // Subtítulo (ou descrição)
                    if (description != null && description!.isNotEmpty)
                      Text(
                        description!, // Agora seguro para ser utilizado
                        style: TextStyle(
                          fontSize: 14,
                          color: appColors.textYellow,
                        ),
                      ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }
}
