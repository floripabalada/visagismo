import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/visagismo/component/progress_bar_component.dart';
import 'package:vip_totem/pages/visagismo/component/top_bar_component.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';

class VisagismoResultView extends ConsumerStatefulWidget {
  const VisagismoResultView({
    super.key,
  });

  @override
  VisagismoResultViewState createState() => VisagismoResultViewState();
}

class VisagismoResultViewState extends ConsumerState<VisagismoResultView> {
  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    final refVisagismoProvider = ref.read(visagismoProvider.notifier);
    final dataVisagismoProvider = refVisagismoProvider.fetchAllData();
    final firstName = ref.read(authProvider).user['primeiro_nome'];

    return Scaffold(
        backgroundColor: appColors.background,
        body: SingleChildScrollView(
          child: SizedBox(
            // height: MediaQuery.of(context).size.height,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 30, bottom: 30),
              child: Column(
                children: [
                  const TopBarComponent(
                    icon: Icons.close,
                    isDialog: false,
                  ),
                  const ProgressBarComponent(totalSteps: 8, currentStep: 8),
                  const SizedBox(height: 20),
                  Text("$firstName, resultado do seu visagismo",
                      style: TextStyle(
                          fontSize: 36, color: appColors.textPrimary)),
                  const SizedBox(height: 20),
                  Text(dataVisagismoProvider['result'],
                      style: TextStyle(
                          fontSize: 20, color: appColors.textPrimary)),
                  const SizedBox(height: 50),
                  const CustomImage(
                    imagePath: 'assets/images/logo_verde.png',
                    width: 80,
                    height: 80,
                    type: 'png',
                  )
                ],
              ),
            ),
          ),
        ));
  }
}
