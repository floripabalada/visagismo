import 'package:vip_totem/models/res_response_model.dart';
import 'package:vip_totem/repositories/user_repository.dart';

class ClientRegistrationController {
  // cria um novo cliente
  Future<ResponseModel> createNewClient(
      {name, email, ddi, phone, birthDate, storeUnit}) async {
    try {
      final data = {
        'nome': name,
        'email': email,
        'ddi': '55',
        'telefone': phone,
        'data_nascimento': birthDate,
        'unidade_id': '1'
      };

      // repassa para o repositório e retorna
      return await UserRepository().clientRegistration(data);
    } catch (error) {
      // seta retorno de erro
      return ResponseModel(success: false, message: error.toString());
    }
  }
}
