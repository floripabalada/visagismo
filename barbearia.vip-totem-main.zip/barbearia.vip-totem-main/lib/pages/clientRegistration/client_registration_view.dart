import 'package:flutter/material.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_button.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_modal_bottom_sheet.dart';
import 'package:vip_totem/components/custom_scaffold_messenger.dart';
import 'package:vip_totem/components/custom_text_form_field.dart';
import 'package:vip_totem/components/lottie_succes_modal.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/models/res_response_model.dart';
import 'package:vip_totem/pages/auth_user/auth_user_controller.dart';
import 'package:vip_totem/pages/clientRegistration/client_registration_controller.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/theme_provider.dart';
import 'package:vip_totem/util/route_util.dart';
import 'package:vip_totem/util/validate_util.dart';

class ClientRegistrationView extends ConsumerStatefulWidget {
  final String phone;
  final Widget? redirectPage;

  const ClientRegistrationView(
      {super.key, required this.phone, this.redirectPage});
  @override
  ClientRegistrationViewState createState() => ClientRegistrationViewState();
}

class ClientRegistrationViewState
    extends ConsumerState<ClientRegistrationView> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();

  late TextEditingController nameController;
  late TextEditingController emailController;
  late TextEditingController phoneController;
  late TextEditingController birthDateController;

  bool isLottieSuccess = false;

  @override
  void initState() {
    super.initState();

    // inicializa os controladores
    nameController = TextEditingController(text: '');
    emailController = TextEditingController(text: '');
    phoneController =
        MaskedTextController(mask: '(00) 00000-0000', text: widget.phone);
    birthDateController = MaskedTextController(mask: '00/00/0000', text: '');
  }

  Future<void> handle() async {
    final modal = CustomModalBottomSheet(context);
    final notifier = CustomScaffoldMessenger(context: context);

    if (formKey.currentState!.validate()) {
      // modal
      modal.showLoading(text: 'Realizando cadastro');

      // registra um novo cliente
      ResponseModel response = await ClientRegistrationController()
          .createNewClient(
              name: nameController.text,
              email: emailController.text,
              ddi: '55',
              phone: phoneController.text,
              birthDate: birthDateController.text,
              storeUnit: 1);

      modal.close();

      if (response.success) {
        // seta o estado para mudar o scaffold
        setState(() {
          isLottieSuccess = true;
        });

        //  define um dealy de 2 segundos para mostrar a animação
        await Future.delayed(const Duration(seconds: 2));

        modal.showLoading(text: 'Autenticando usuário');

        // faz a autenticação do usuário
        ResponseModel responseAuth =
            await AuthUserController().auth(phoneController.text);

        // salva no provider
        ref.read(authProvider).login(responseAuth.data);

        modal.close();

        // ignore: use_build_context_synchronously
        redirectPage(context, widget.redirectPage!, type: 'clearStack');
      } else {
        notifier.show(message: "Ops... ${response.message} ");
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    final isDark = ref.watch(themeProvider).isDark;

    return isLottieSuccess
        ? const CustomLottieScaffold(
            message: "Seu cadastro foi realizado com sucesso!")
        : Scaffold(
            backgroundColor: appColors.background,
            body: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 75, right: 75, top: 40, bottom: 60),
                child: Column(
                  children: [
                    CustomImage(
                      imagePath: isDark
                          ? 'assets/images/logo_amarela.png'
                          : 'assets/images/logo_verde.png',
                      width: 200,
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      child: Text(
                          'Ops... vimos que você não possui cadastro, preencha e continue.',
                          style: TextStyle(
                              fontSize: 18, color: appColors.textPrimary)),
                    ),
                    const SizedBox(height: 100),
                    Form(
                      key: formKey,
                      child: Column(
                        children: [
                          CustomTextFormField(
                            controller: nameController,
                            label: 'Nome',
                            keyboardType:
                                TextInputType.text, // Corrigido para texto
                            icon: Icons.person,
                            validator: (value) {
                              return (value == null || value.isEmpty)
                                  ? 'Informe seu nome'
                                  : null;
                            },
                          ),
                          const SizedBox(height: 20),
                          CustomTextFormField(
                            controller: emailController,
                            label: 'E-mail',
                            keyboardType: TextInputType.emailAddress,
                            icon: Icons.email_outlined,
                            validator: (value) {
                              return (validateEmail(value.toString()) == false)
                                  ? 'Informe um email válido'
                                  : null;
                            },
                          ),
                          const SizedBox(height: 20),
                          CustomTextFormField(
                            controller: phoneController,
                            label: 'Telefone',
                            keyboardType: TextInputType.phone,
                            icon: Icons.phone,
                            enabled: false,
                            validator: (value) {
                              return (validatePhoneNumber(value.toString()) ==
                                      false)
                                  ? 'Informe um telefone válido'
                                  : null;
                            },
                          ),
                          const SizedBox(height: 20),
                          CustomTextFormField(
                            controller: birthDateController,
                            label: 'Data de nascimento',
                            keyboardType: TextInputType.datetime,
                            icon: Icons.calendar_today_outlined,
                            isNumericKeyboard: true,
                            validator: (value) {
                              return (validateDate(value.toString()) == false)
                                  ? 'Informe uma data válida'
                                  : null;
                            },
                          ),
                          const SizedBox(height: 50),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              SizedBox(
                                width: 200,
                                child: CustomButton(
                                  onPressed: () async {
                                    Navigator.pop(context);
                                  },
                                  positionIcon: 'after',
                                  icon: Icons.navigate_before,
                                  text: 'Cancelar',
                                  backgroundColor: appColors.backgroundGray,
                                  iconColor: appColors.textGrey,
                                  textColor: appColors.textGrey,
                                ),
                              ),
                              const SizedBox(width: 30),
                              SizedBox(
                                width: 200,
                                child: CustomButton(
                                  onPressed: handle,
                                  icon: Icons.navigate_next,
                                  text: 'Avançar',
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
  }
}
