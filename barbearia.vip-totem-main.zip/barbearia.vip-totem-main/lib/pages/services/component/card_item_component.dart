import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:vip_totem/config/environment.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CardItemComponent extends StatelessWidget {
  final dynamic data;

  const CardItemComponent({Key? key, required this.data}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    // Verificando se os dados existem e se não são nulos``
    final date = data['date'] ?? {};
    final items = data['items'];
    final storeUnit = data['storeUnit'] ?? '-';

    return SizedBox(
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text(
                  date['day'] ?? '-',
                  style: TextStyle(
                    fontSize: 40,
                    color: appColors.textGrey4,
                  ),
                ),
                Text(
                  date['month'] ?? '-',
                  style: TextStyle(
                    fontSize: 20,
                    color: appColors.textGrey2,
                    height: 0.55,
                  ),
                ),
                Text(
                  date['year'] ?? '-',
                  style: TextStyle(
                    fontSize: 20,
                    color: appColors.textGrey2,
                  ),
                ),
              ],
            ),
            const SizedBox(width: 20), // Espaçamento entre as colunas
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'unidade:',
                        style:
                            TextStyle(fontSize: 15, color: appColors.textGrey),
                      ),
                      Text(
                        storeUnit,
                        style: TextStyle(
                          fontSize: 24,
                          color: appColors.textGreen,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 7,
                    children: items.isNotEmpty
                        ? items.map<Widget>((dataItem) {
                            return ServiceItem(
                              serviceName: dataItem['product'] ?? '-',
                            );
                          }).toList()
                        : [const Text('-')],
                  ),
                  const SizedBox(height: 20),
                  // Seção para exibir foto do profissional e nome
                  ProfessionalInfo(
                      name: data['employee']['name'],
                      url: data['employee']['imageUrl']),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// Widget para exibir os itens de serviço com fundo colorido
class ServiceItem extends StatelessWidget {
  final String serviceName;

  const ServiceItem({Key? key, required this.serviceName}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 1),
      decoration: BoxDecoration(
        color: appColors.backGroundQuinary,
        borderRadius: BorderRadius.circular(3),
      ),
      child: Text(
        serviceName,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: appColors.textWhite,
        ),
      ),
    );
  }
}

// Widget para exibir a foto e o nome do profissional
class ProfessionalInfo extends StatelessWidget {
  final String name;
  final String url;

  const ProfessionalInfo({Key? key, required this.name, required this.url})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    return Row(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        CircleAvatar(
          radius: 30,
          backgroundImage: (url.isNotEmpty)
              ? NetworkImage(
                  kIsWeb
                      ? url.replaceFirst(
                          Environment.baseUrlProd, Environment.baseUrlDev)
                      : url,
                ) as ImageProvider<Object>
              : const AssetImage('assets/images/malvino.png'),
          // backgroundColor: AppColors.backgroundGray2,
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Profissional',
              style: TextStyle(
                fontSize: 16,
                color: appColors.textGrey4,
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              name,
              style: TextStyle(
                fontSize: 18,
                color: appColors.textQuaternary,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
