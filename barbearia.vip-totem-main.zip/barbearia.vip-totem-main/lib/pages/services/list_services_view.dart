import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_app_bar.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/services/component/card_item_component.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/theme_provider.dart';

class ListServicesView extends ConsumerStatefulWidget {
  const ListServicesView({super.key});

  @override
  ListServicesViewState createState() => ListServicesViewState();
}

class ListServicesViewState extends ConsumerState<ListServicesView> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    final isDark = ref.watch(themeProvider).isDark;
    final refAuthProvider = ref.watch(authProvider);

    final firstName = refAuthProvider.user['primeiro_nome'];
    final history = refAuthProvider.user['history'];

    return Scaffold(
      appBar: const CustomAppBar(),
      backgroundColor: appColors.background,
      body: SingleChildScrollView(
        child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 0, bottom: 60),
              child: Column(
                children: [
                  Column(
                    children: [
                      CustomImage(
                        imagePath: isDark
                            ? 'assets/images/logo_amarela.png'
                            : 'assets/images/logo_verde.png',
                        width: 200,
                      ),
                      const SizedBox(height: 20),
                      RichText(
                        text: TextSpan(
                          children: <TextSpan>[
                            TextSpan(
                              text: firstName,
                              style: TextStyle(
                                color: appColors.textGreen,
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            TextSpan(
                              text: ", veja todos os serviços realizados.",
                              style: TextStyle(
                                color: appColors.textGrey,
                                fontSize: 20,
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 100,
                        child: Icon(
                          Icons.keyboard_double_arrow_down,
                          size: 30,
                          color: appColors.primary,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  history != null
                      ? Column(
                          children: history.map<Widget>((data) {
                            return Column(
                              children: [
                                CardItemComponent(data: data),
                                Divider(
                                  color: appColors.gray,
                                  thickness: 0.2,
                                ),
                              ],
                            );
                          }).toList(),
                        )
                      : Text(
                          'Nenhum serviço realizado.',
                          style: TextStyle(
                              fontSize: 20, color: appColors.textGrey),
                        ),
                ],
              ),
            )),
      ),
    );
  }
}
