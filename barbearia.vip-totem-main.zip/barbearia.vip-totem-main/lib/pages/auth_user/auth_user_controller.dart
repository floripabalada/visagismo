import 'package:vip_totem/models/res_response_model.dart';
import 'package:vip_totem/repositories/auth_repository.dart';

class AuthUserController {
  Future<ResponseModel> auth(String phone) async {
    // normaliza o dado
    phone = (phone)
        .replaceAll('(', '')
        .replaceAll(')', '')
        .replaceAll(' ', '')
        .replaceAll('-', '');

    try {
      // autentica o cliente
      return await AuthRepository().auth(phone);
    } catch (error) {
      // retorna o erro
      return ResponseModel(success: false, message: error.toString());
    }
  }
}
