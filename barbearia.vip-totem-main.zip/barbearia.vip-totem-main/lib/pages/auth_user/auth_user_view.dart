import 'package:flutter/material.dart';
import 'package:flutter_masked_text2/flutter_masked_text2.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_button.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_modal_bottom_sheet.dart';
import 'package:vip_totem/components/custom_scaffold_messenger.dart';
import 'package:vip_totem/components/custom_text_form_field.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/models/res_response_model.dart';
import 'package:vip_totem/pages/auth_user/auth_user_controller.dart';
import 'package:vip_totem/pages/clientRegistration/client_registration_view.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/theme_provider.dart';
import 'package:vip_totem/util/route_util.dart';
import 'package:vip_totem/util/validate_util.dart';

class AuthUserView extends ConsumerStatefulWidget {
  final Widget? redirectPage;

  const AuthUserView({super.key, this.redirectPage});
  @override
  AuthUserViewState createState() => AuthUserViewState();
}

class AuthUserViewState extends ConsumerState<AuthUserView> {
  final GlobalKey<FormState> formKey = GlobalKey<FormState>();
  final TextEditingController phoneController =
      MaskedTextController(mask: '(00) 00000-0000', text: '');

  // instancia o controller
  AuthUserController controller = AuthUserController();

  Future<void> handle() async {
    final loading = CustomModalBottomSheet(context);
    final notifier = CustomScaffoldMessenger(context: context);

    // verifica validação de formulario
    if (formKey.currentState!.validate()) {
      // loading
      loading.showLoading(text: 'Identificando cliente');

      // faz a autenticação do cliente
      final ResponseModel response =
          await controller.auth(phoneController.text);

      if (response.success) {
        // atualiza o provider
        ref.read(authProvider).login(response.data);

        // ignore: use_build_context_synchronously
        redirectPage(
          context,
          widget.redirectPage!,
          type: 'clearStack',
        );
      } else {
        //  mensagme de erro
        notifier.show(message: response.message, seconds: 5);

        // cliente não cadastrado
        if (response.message.contains('não cadastrado')) {
          // redireciona para o cadastro
          redirectPage(
              // ignore: use_build_context_synchronously
              context,
              ClientRegistrationView(
                phone: phoneController.text,
                redirectPage: widget.redirectPage!,
              ));
        }

        loading.close();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    final isDark = ref.watch(themeProvider).isDark;

    return Scaffold(
        backgroundColor: appColors.background,
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 100, bottom: 60),
              child: Column(
                children: [
                  Expanded(
                      child: CustomImage(
                    imagePath: isDark
                        ? 'assets/images/logo_amarela.png'
                        : 'assets/images/logo_verde.png',
                    width: 400,
                    height: 190,
                  )),
                  Expanded(
                    flex: 4,
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const SizedBox(height: 50),
                          Form(
                              key: formKey,
                              child: CustomTextFormField(
                                controller: phoneController,
                                label: 'Telefone',
                                keyboardType: TextInputType.number,
                                isNumericKeyboard: true,
                                icon: Icons.phone,
                                validator: (value) {
                                  // valida o telefone
                                  return (!validatePhoneNumber(
                                          value.toString()))
                                      ? 'Telefone inválido'
                                      : null;
                                },
                              )),
                          const SizedBox(height: 20),
                          CustomButton(
                            onPressed: handle,
                            icon: Icons.navigate_next,
                            text: 'Avançar',
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ));
  }
}
