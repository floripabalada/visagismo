import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_app_bar.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/balance/component/card_item_component.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/theme_provider.dart';

class ListBalanceView extends ConsumerStatefulWidget {
  const ListBalanceView({super.key});

  @override
  ListBalanceViewState createState() => ListBalanceViewState();
}

class ListBalanceViewState extends ConsumerState {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();
    final isDark = ref.watch(themeProvider).isDark;
    final refAuthProvider = ref.watch(authProvider);

    final firstName = refAuthProvider.user['primeiro_nome'];
    final balance = refAuthProvider.user['balance'];

    return Scaffold(
        backgroundColor: appColors.background,
        appBar: const CustomAppBar(),
        body: SingleChildScrollView(
          child: SizedBox(
            width: MediaQuery.of(context).size.width,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 0, bottom: 60),
              child: Column(
                children: [
                  SizedBox(
                      child: Column(
                    children: [
                      CustomImage(
                        imagePath: isDark
                            ? 'assets/images/logo_amarela.png'
                            : 'assets/images/logo_verde.png',
                        width: 200,
                        // height: 200,
                      ),
                      SizedBox(
                          child: RichText(
                        text: TextSpan(
                          children: <TextSpan>[
                            TextSpan(
                              text: firstName,
                              style: TextStyle(
                                  color: appColors.textGreen,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            ),
                            TextSpan(
                              text: ", acompanhe a sua pontuação.",
                              style: TextStyle(
                                  color: appColors.textGrey, fontSize: 20),
                            ),
                          ],
                        ),
                      )),
                    ],
                  )),
                  const SizedBox(height: 50),
                  balance != null
                      ? Column(
                          children: balance.map<Widget>((data) {
                            return Column(
                              children: [
                                CardItemComponent(data: data),
                                Divider(
                                  color: appColors.gray,
                                  thickness: 0.2,
                                ),
                              ],
                            );
                          }).toList(),
                        )
                      : Text(
                          'Nenhum registro de pontos',
                          style: TextStyle(
                              fontSize: 20, color: appColors.textGrey),
                        ),
                ],
              ),
            ),
          ),
        ));
  }
}
