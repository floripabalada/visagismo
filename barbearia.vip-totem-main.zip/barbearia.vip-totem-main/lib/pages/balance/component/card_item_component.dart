import 'package:flutter/material.dart';
import 'package:vip_totem/shared/app_colors.dart';

class CardItemComponent extends StatelessWidget {
  final dynamic data;

  const CardItemComponent({super.key, required this.data});
  

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    // Verificando se os dados existem e se não são nulos``
    final storeUnit = data['storeUnit'] ?? '-';
    final credit = (data['maskCredit'] ?? '-').toString();

    return SizedBox(
      child: Container(
        width: 600,
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            SizedBox(
                child: Wrap(
              children: [
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: appColors.backGroundQuinary,
                    borderRadius: BorderRadius.circular(3),
                  ),
                  child: Text(
                    credit,
                    style: TextStyle(color: appColors.textWhite, fontSize: 20),
                  ),
                )
              ],
            )),
            const SizedBox(width: 20),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'unidade:',
                        style:
                            TextStyle(fontSize: 15, color: appColors.textGrey),
                      ),
                      Text(
                        storeUnit,
                        style: TextStyle(
                          fontSize: 24,
                          color: appColors.textQuaternary,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
