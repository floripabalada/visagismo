import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/components/custom_button_icon.dart';
import 'package:vip_totem/components/custom_button_menu.dart';
import 'package:vip_totem/components/custom_dialog.dart';
import 'package:vip_totem/components/custom_image.dart';
import 'package:vip_totem/components/custom_rotating_text.dart';
import 'package:vip_totem/shared/app_colors.dart';
import 'package:vip_totem/pages/balance/list_balance_view.dart';
import 'package:vip_totem/pages/auth_user/auth_user_view.dart';
import 'package:vip_totem/pages/services/list_services_view.dart';
import 'package:vip_totem/pages/visagismo/visagismo_step1_view.dart';
import 'package:vip_totem/providers/auth_provider.dart';
import 'package:vip_totem/providers/theme_provider.dart';
import 'package:vip_totem/providers/visagismo_provider.dart';
import 'package:vip_totem/shared/inactivityService.dart';
import 'package:vip_totem/util/route_util.dart';

class MenuView extends ConsumerStatefulWidget {
  const MenuView({super.key});

  @override
  MenuViewState createState() => MenuViewState();
}

class MenuViewState extends ConsumerState {
  @override
  void initState() {
    super.initState();

    // inicilizado para controlar a cada 2 minutos sem interação
    // direcionar para o logout
    // cria o serviço
    InactivityService().initialize(() {
      try {
        // seta o provider do usuário
        final refAuthProvider = ref.watch(authProvider);

        // força o logout
        refAuthProvider.logout();
      } catch (e) {
        debugPrint("Erro: InactivityService().initialize: ");
      }

      // executa o redirect
      redirectPage(context, const MenuView());
    });
  }

  // troca o tema para dark ou light
  void changeTheme() {
    // instancia o provider
    final refThemeProvider = ref.watch(themeProvider);

    refThemeProvider.change();
  }

  @override
  Widget build(BuildContext context) {
    final appColors = AppColors();

    final isDark = ref.watch(themeProvider).isDark;
    final visagismoNotifier = ref.read(visagismoProvider.notifier);
    final refAuthProvider = ref.watch(authProvider);

    String labelFirstName = refAuthProvider.user['primeiro_nome'] ?? '';
    bool isAuthenticated = refAuthProvider.user.isEmpty ? false : true;

    return Scaffold(
        backgroundColor: appColors.background,
        body: SingleChildScrollView(
          child: SizedBox(
            height: MediaQuery.of(context).size.height,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 75, right: 75, top: 30, bottom: 60),
              child: Column(
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      if (isAuthenticated)
                        Align(
                          alignment: Alignment.topLeft,
                          child: SizedBox(
                            child: RichText(
                              text: TextSpan(
                                children: <TextSpan>[
                                  TextSpan(
                                    text: "Olá ",
                                    style: TextStyle(
                                        color: appColors.textGrey,
                                        fontSize: 20),
                                  ),
                                  TextSpan(
                                    text: labelFirstName,
                                    style: TextStyle(
                                        color: appColors.textGreen,
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  TextSpan(
                                    text: ", legal ver você aqui!",
                                    style: TextStyle(
                                        color: appColors.textGrey,
                                        fontSize: 20),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      Align(
                          alignment: Alignment.topRight,
                          child: CustomButtonIcon(
                            icon: Icons.light_mode,
                            color: isDark
                                ? appColors.backGroundQuinary
                                : appColors.backgroundGray2,
                            onPressed: changeTheme,
                          )),
                    ],
                  ),
                  const SizedBox(height: 30),
                  Expanded(
                      flex: 1,
                      child: Column(
                        children: [
                          CustomImage(
                            imagePath: isDark
                                ? 'assets/images/logo_amarela.png'
                                : 'assets/images/logo_verde.png',
                            width: 400,
                            height: 150,
                          ),
                          CustomRotatingText(
                              texts: const [
                                "Você está na maior rede de barberias da América Latina",
                                "Pioneira no conceito de 'barbearia premium'",
                                "Já baixou nosso App?"
                              ],
                              secondsExchange: 950,
                              seconds: 4,
                              style: TextStyle(
                                fontSize: 14,
                                color: appColors.textGrey,
                              ))
                        ],
                      )),
                  Expanded(
                      flex: 3,
                      child: Center(
                          child: Column(
                        children: [
                          const SizedBox(height: 50),
                          CustomButtonMenu(
                              onPressed: () {
                                // seta o provider de visagismo
                                visagismoNotifier.reset();

                                // redireciona para o visagismo
                                redirectPage(
                                    context,
                                    isAuthenticated
                                        ? const VisagismoStep1View()
                                        : const AuthUserView(
                                            redirectPage:
                                                VisagismoStep1View()));
                              },
                              title: 'Visagismo',
                              description: 'Consultoria padrão Vip',
                              icon: Icons.person),
                          const SizedBox(height: 20),
                          CustomButtonMenu(
                              onPressed: () => {
                                    redirectPage(
                                        context,
                                        isAuthenticated
                                            ? const ListBalanceView()
                                            : const AuthUserView(
                                                redirectPage:
                                                    ListBalanceView()))
                                  },
                              title: 'Consultar pontos',
                              description: 'Programa de fidelidade Vip',
                              icon: Icons.monetization_on),
                          const SizedBox(height: 20),
                          CustomButtonMenu(
                              onPressed: () => {
                                    redirectPage(
                                        context,
                                        isAuthenticated
                                            ? const ListServicesView()
                                            : const AuthUserView(
                                                redirectPage:
                                                    ListServicesView()))
                                  },
                              title: 'Serviços utilizados',
                              description: 'Você sendo Vip',
                              icon: Icons.checklist),
                          const SizedBox(height: 20),
                          if (isAuthenticated)
                            CustomButtonMenu(
                                onPressed: () async {
                                  CustomDialog.show(
                                      context: context,
                                      title:
                                          "$labelFirstName, deseja realmente sair?",
                                      content: 'Se for, te espero em breve!',
                                      onConfirm: () {
                                        // faz o logout do cliente
                                        refAuthProvider.logout();

                                        // redireciona
                                        redirectPage(context, const MenuView());
                                      },
                                      btnTextActionLeft: 'Não',
                                      btnActionLeft: () => {});
                                },
                                // isDisabled: true,
                                title: 'Sair',
                                description:
                                    "$labelFirstName, nos vemos em breve!",
                                icon: Icons.logout)
                        ],
                      ))),
                ],
              ),
            ),
          ),
        ));
  }
}
