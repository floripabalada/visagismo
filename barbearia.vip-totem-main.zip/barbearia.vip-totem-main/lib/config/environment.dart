import 'package:flutter/foundation.dart';

class Environment {
  static const String baseUrlDev = 'http://localhost:3000';
  static const String baseUrlProd = 'https://www.franquiabv.com.br';

  static String get baseUrlApi {
    switch (kIsWeb) {
      case true:
        return 'http://localhost:3000/api';
      default:
        return 'http://localhost:3000/api';
    }
  }

  static const String plugZapiUrl = 'https://api.plugzapi.com.br/';
  static const String plugZapiToken = '0C7D15034E8FA03D8307FBB6';
  static const String plugZapiIdInstance = '3D9DDC48AA8250C7BB54F67E0E03CD43';
  static const String plugzapiClientToken =
      'Fe65cd2d8f0204c7e93ffc4eba1a08d41S';

  // mapeamento do storage
  static Map<String, dynamic> refStorageLocal = {
    "repositoryApp": "repository_app",
    "cache": "repository_cache",
    "user": "storage_user",
    "auth": "storage_auth",
    "userNotification": "user_notification"
  };
}
