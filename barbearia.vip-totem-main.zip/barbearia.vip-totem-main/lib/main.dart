import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:vip_totem/pages/menu/menu_view.dart';
import 'package:vip_totem/shared/inactivityService.dart';
import 'package:vip_totem/util/theme.dart';

// Solicitar permissão para usar a câmera
Future<void> requestPermissions() async {
  await Permission.camera.request();
  // await Permission.microphone.request(); // Se for gravar vídeo também
}

void main() async {
  // IMPLEMENTAR: adicionar o splash -> runApp(const Splash());

  WidgetsFlutterBinding.ensureInitialized();
  Permission.camera.request();

  await Future.wait([
    // await Firebase.initializeApp(),
    // await FirebaseMessagingService().initialize(),
  ]);

  runApp(const App());
}

class App extends ConsumerWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ProviderScope(
        child: Listener(
      behavior: HitTestBehavior.translucent,
      onPointerDown: (_) => InactivityService().userInteractionDetected(),
      child: MaterialApp(
        theme: configTheme,
        home: const MenuView(),
      ),
    ));
  }
}
