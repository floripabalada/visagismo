import 'package:vip_totem/models/cliente_model.dart';
import 'package:vip_totem/models/res_response_model.dart';
import 'package:vip_totem/repositories/api_service.dart';
import 'package:vip_totem/repositories/user_repository.dart';

class AuthRepository extends ResponseModel {
  Future<ResponseModel> auth(phone) async {
    // consulta os dados do cliente
    dynamic response = await ApiService.get(
        "/agendas/getCliente?telefone=$phone",
        isToken: false);

    // normaliza os dados de retorno
    success = response['sucesso'];

    if (!success) throw Exception('Cliente não cadastrado');

    // seta o cliente
    ClientModel client = ClientModel.fromJson(response['clientes'][0]);
    String clientId = client.id.toString();

    if (success) {
      try {
        // busca o histórico e pontuação do cliente
        dynamic response = await UserRepository.fetchAllPointBalanceAndServices(
            clientId: clientId);

        client.history = response['history'];
        client.balance = response['balance'];
        client.pointsBalance = 0.0;
      } catch (error) {
        throw Exception('Falha na solicitação, tente novamente.');
      }

      // seta os dados
      data = client.toJson();
    } else {
      throw Exception('Cliente não cadastrado');
    }

    return getResponse();
  }
}
