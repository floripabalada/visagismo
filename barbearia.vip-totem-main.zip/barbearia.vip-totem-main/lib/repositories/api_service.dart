import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:vip_totem/config/environment.dart';
// import 'package:vip_totem/service/auth_service.dart';

class ApiService {
  // Método post
  static Future<Map<String, dynamic>> post(
      String endpoint, Map<String, dynamic> data,
      {bool isToken = true}) async {
    // define o endereço e o endpoint
    final uri = Uri.parse("${Environment.baseUrlApi}$endpoint");
    // monta o cabeçalho
    final headers = {"Content-Type": "application/json"};
    String token = "";
    String userId = "";

    // print(endpoint);

    // adiciona os tokens de autenticação
    if (isToken) {
      // consulta o token
      // final auth = await AuthService.load();

      // // seta token e userId
      // token = auth['token'].toString();
      // userId = auth['userId'].toString();

      // headers.addAll({"authorization": token});
      // headers.addAll({"userid": userId});
    }

    try {
      // faz uma requisição POST
      final response = await http
          .post(uri, headers: headers, body: jsonEncode(data))
          .timeout(const Duration(seconds: 20));

      // se der permissão negada
      if (response.statusCode == 401 && isToken) {
        // gera um novo token
        final responseToken = await refreshToken(token, userId);

        if (responseToken['success']) {
          // final newToken = responseToken['data']['token'];
          // registra o novo token no storage
          // await AuthService.save(newToken, userId);

          // seta o novo token ao cabeçalho
          // headers["authorization"] = newToken;

          final retryResponse = await http
              .post(uri, headers: headers, body: jsonEncode(data))
              .timeout(const Duration(seconds: 20));

          // decodifica os dados
          final Map<String, dynamic> retryDataResponse =
              jsonDecode(retryResponse.body);

          // retorno da requisição
          return retryDataResponse;
        } else {
          throw handleException("Acesso negado. Token ou usuário inválido");
        }
      }

      // decodifica os dados
      final Map<String, dynamic> dataResponse = jsonDecode(response.body);

      return dataResponse;
    } catch (error) {
      throw handleException("$error");
    }
  }

  // Método get
  static Future<dynamic> get(String endpoint,
      {bool isToken = true, bool isBinary = false}) async {
    // Define o endereço e o endpoint
    final uri = Uri.parse('${Environment.baseUrlApi}$endpoint');
    // Monta o cabeçalho
    final headers = {"Content-Type": "application/json"};
    String token = "";
    String userId = "";

    print(uri);

    // Adiciona os tokens de autenticação
    // if (isToken) {
    //   // Consulta o token
    //   final auth = await AuthService.load();

    //   // Seta token e userId
    //   token = auth['token'].toString();
    //   userId = auth['userId'].toString();

    //   headers.addAll({"authorization": token});
    //   headers.addAll({"userid": userId});
    // }

    try {
      // Faz uma requisição GET
      final response = await http
          .get(uri, headers: headers)
          .timeout(const Duration(seconds: 20));

      // Se der permissão negada
      if (response.statusCode == 401 && isToken) {
        // Gera um novo token
        final responseToken = await refreshToken(token, userId);

        if (responseToken['success']) {
          // final newToken = responseToken['data']['token'];
          // Registra o novo token no storage
          // await AuthService.save(newToken, userId);

          // Seta o novo token ao cabeçalho
          // headers["authorization"] = newToken;

          // Faz a requisição novamente
          final retryResponse = await http
              .get(uri, headers: headers)
              .timeout(const Duration(seconds: 20));

          if (isBinary) {
            return retryResponse.bodyBytes; // Retorna os bytes do PDF
          } else {
            return jsonDecode(retryResponse.body); // Retorna o JSON
          }
        } else {
          throw handleException("Acesso negado. Token ou usuário inválido");
        }
      }

      // Verifica o tipo de resposta esperado
      if (isBinary) {
        return response.bodyBytes; // Retorna os bytes do PDF
      } else {
        return jsonDecode(response.body); // Retorna o JSON
      }
    } catch (error) {
      throw handleException("$error");
    }
  }

  static handleException(String error) {
    if (error.contains("Connection refused")) {
      return "Sem conexão com Api";
    }

    return error;
  }

  static Future refreshToken(token, userId) async {
    try {
      // faz uma nova solicitação de token
      return await post(
          '/user/refreshToken', {"token": token, "userId": userId},
          isToken: false);
    } catch (error) {
      return {"success": false, "message": "Error token: $error"};
    }
  }
}
