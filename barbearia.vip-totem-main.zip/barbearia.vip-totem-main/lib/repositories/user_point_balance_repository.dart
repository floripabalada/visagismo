import 'package:vip_totem/repositories/api_service.dart';

class UserPointBalanceRepository {
  // busca pontos de todas as unidade
  Future<dynamic> fetchAll({clientId}) async {
    try {
      //
      Map<String, dynamic> response =
          await ApiService.get("/agendas/getConsumoCliente?id=$clientId");

      if (response['sucesso'] == false) {
        throw Exception(response['message']);
      }

      //
    } catch (error) {
      //
    }
  }
}
