import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:vip_totem/config/environment.dart';
import 'package:vip_totem/models/res_response_model.dart';
import 'package:vip_totem/repositories/api_service.dart';
import 'package:vip_totem/util/date_util.dart';

class UserRepository {
  // busca pontos de todas as unidade
  static Future<dynamic> fetchAllPointBalanceAndServices({clientId}) async {
    // faz a solicitação na API
    Map<String, dynamic> response =
        await ApiService.get("/agendas/getConsumoCliente?id=$clientId");

    if (response['sucesso'] == true) {
      List<Map<String, dynamic>> history =
          List<Map<String, dynamic>>.from(response['historico']);
      List<Map<String, dynamic>> balance =
          List<Map<String, dynamic>>.from(response['pontuacoes']);

      List<Map<String, dynamic>> resultHistory = [];
      List<Map<String, dynamic>> resultBalance = [];

      // remonta o histórico
      for (var dataHistory in history) {
        // A lista de itens de cada unidade
        List<Map<String, dynamic>> itemsHistory =
            List<Map<String, dynamic>>.from(dataHistory['itens']);

        dynamic listEmployee = [];
        dynamic employee = {};

        // TODO:: REESTRUTURA ESSE SCRIPT // VIR DA BASE JÁ DA MANEIRA CORRETA
        for (var dataEmployee in itemsHistory) {
          // dados do colaborador
          employee = {
            'id': dataEmployee['colaborador_id'],
            'name': dataEmployee['colaborador'],
            'imageUrl': dataEmployee['colaborador_imagem_url']
          };

          try {
            // Adiciona o serviço realizado ao colaborador
            listEmployee.add({"product": dataEmployee['produto_servico']});
          } catch (error) {
            print(error);
          }
        }

        // splita a string pra pegar somente uma parte das unidade
        final storeUnit = dataHistory['unidade'].split(' - ');

        // agrupo por dia e itens do dia
        resultHistory.add({
          'date': DateUtil.formatDateForAllTypes(dataHistory['data']),
          'storeUnit': "${storeUnit[3]} (${storeUnit[2]})",
          'employee': employee,
          'items': listEmployee
        });
      }

      // remonta a parte de pontuação
      for (var dataBalance in balance) {
        // splita a string pra pegar somente uma parte das unidade
        final storeUnit = dataBalance['unidade'].split(' - ');

        resultBalance.add({
          'storeUnit': "${storeUnit[2]} (${storeUnit[1]})",
          'credit': dataBalance['credit'],
          'balance': dataBalance['pontuacao'],
          'maskCredit': dataBalance['credito_mascara']
        });
      }

      // Retorna os dados finais: histórico e pontos
      return {'history': resultHistory, 'balance': resultBalance};
    } else {
      // Em caso de erro, pode adicionar tratamento aqui
      return {"error": "Falha ao buscar os dados."};
    }
  }

  Future<ResponseModel> clientRegistration(Map<String, dynamic> item) async {
    // seta a url de cadastros
    var uri = Uri.parse("${Environment.baseUrlApi}/clientes/novo");

    // cria o request
    var request = http.MultipartRequest('POST', uri);

    request.fields['nome'] = item['nome'];
    request.fields['email'] = item['email'];
    request.fields['ddi'] = item['ddi'];
    request.fields['telefone'] = item['telefone'];
    request.fields['data_nascimento'] = item['data_nascimento'];
    request.fields['unidade_id'] = item['unidade_id'];

    // Envia a requisição
    var response = await request.send();

    // Verificando o status da resposta
    if (response.statusCode == 200) {
      // retorno da api
      final result = jsonDecode(await response.stream.bytesToString());

      return ResponseModel(
          success: result['sucesso'], message: result['mensagem'] ?? '');
    } else {
      throw Exception("Erro Api");
    }
  }
}
