import 'package:flutter/material.dart';
import 'package:vip_totem/util/global.dart';

class AppColors {
  late bool isDark;

  AppColors() {
    // pega da variável global
    isDark = themeIsDark;
  }

  // Cores primárias (controladas por isDark)
  Color get primary =>
      isDark ? const Color(0xFF212121) : const Color(0xFFD9D9D9);
  Color get secundary =>
      isDark ? const Color(0xFF50F2D4) : const Color(0xFF50F2D4);
  Color get terciary =>
      isDark ? const Color(0xFF413973) : const Color(0xFF413973);
  Color get quaternary =>
      isDark ? const Color(0xFF03A696) : const Color(0xFF03A696);
  Color get gray => isDark ? const Color(0xFF888888) : const Color(0xFFB7B7B7);
  Color get white => isDark ? const Color(0xFF212121) : Colors.white;

  // Cores de fundo (controladas por isDark)
  Color get background =>
      isDark ? const Color(0xFF212121) : const Color(0xFFFFFFFF);
  Color get backgroundSecundary =>
      isDark ? const Color(0xFF13563A) : const Color(0xFF13563A);
  Color get backgroundQuaternary =>
      isDark ? const Color(0xFF323232) : const Color(0xFFA4A4A4);
  Color get backgroundGray =>
      isDark ? const Color(0xFF323232) : const Color(0xFFE8E8E8);
  Color get backgroundGray2 =>
      isDark ? const Color(0xFF1E1E1E) : const Color(0xFF3D3D3D);
  Color get backGroundQuinary =>
      isDark ? const Color(0xFF66B369) : const Color(0xFF66B369);
  Color get backGroundRed =>
      isDark ? const Color(0xFFBE3C3C) : const Color(0xFFBE3C3C);

  // Cores de texto (controladas por isDark)
  Color get textPrimary =>
      isDark ? const Color(0xFFFFFFFF) : const Color(0xFF212121);
  Color get textQuaternary =>
      isDark ? const Color(0xFF66B369) : const Color(0xFF66B369);
  Color get textGreen =>
      isDark ? const Color(0xFF13563A) : const Color(0xFF13563A);
  Color get textGrey =>
      isDark ? const Color(0xFF888888) : const Color(0xFF888888);
  Color get textGrey2 =>
      isDark ? const Color(0xFFA4A4A4) : const Color(0xFFA4A4A4);
  Color get textGrey3 =>
      isDark ? const Color(0xFFD3D3D3) : const Color(0xFFD3D3D3);
  Color get textGrey4 =>
      isDark ? const Color(0xFF3D3D3D) : const Color(0xFF3D3D3D);
  Color get textWhite => isDark ? Colors.white : Colors.white;
  Color get textYellow =>
      isDark ? const Color(0xFFDAB337) : const Color(0xFFDAB337);

  // Cores de ícone
  Color get iconPrimary =>
      isDark ? const Color(0xFF66B369) : const Color(0xFF66B369);
}
