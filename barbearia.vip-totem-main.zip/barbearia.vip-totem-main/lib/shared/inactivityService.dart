import 'dart:async';
import 'package:flutter/material.dart';

class InactivityService {
  static final InactivityService _instance = InactivityService.internal();
  factory InactivityService() => _instance;
  InactivityService.internal();

  Timer? inactivityTimer;
  final Duration timeout = const Duration(minutes: 2);
  VoidCallback? eventCallback;

  void initialize(VoidCallback onTimeout) {
    eventCallback = onTimeout;
    resetTimer();
  }

  void resetTimer() {
    inactivityTimer?.cancel();
    inactivityTimer = Timer(timeout, handleTimeout);
  }

  void handleTimeout() {
    if (eventCallback != null) {
      eventCallback!();
    }
  }

  void userInteractionDetected() {
    resetTimer();
  }

  void dispose() {
    inactivityTimer?.cancel();
  }
}
