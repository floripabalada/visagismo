import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';

// Define o estado da autenticação
class VisagismoState {
  final String currentStep;
  final dynamic data;
  final dynamic repository;

  VisagismoState({this.currentStep = '', this.data, this.repository});

  factory VisagismoState.initial() {
    return VisagismoState(
      currentStep: '',
      data: {
        'qt1': '',
        'qt2': '',
        'qt3': '',
        'qt4': '',
        'qt5': '',
        'image': Uint8List(0),
        'result': ''
      },
    );
  }

  VisagismoState copyWith({
    String? currentStep,
    dynamic data,
  }) {
    return VisagismoState(
      currentStep: currentStep ?? this.currentStep,
      data: data ?? this.data,
    );
  }
}

// Criar o provider
class VisagismoProvider extends StateNotifier<VisagismoState> {
  VisagismoProvider() : super(VisagismoState.initial());

  // salva os dados do passo corrente
  Future saveStep(String step, dynamic item) async {
    // seta o passao com os dados referente ao mesmo
    state.data[step] = item;

    // atualiza
    state.copyWith(currentStep: step, data: state.data);
  }

  // retorna os dados de um determinado passo
  fetchStep(String step) {
    return state.data[step] ?? '';
  }

  // retorna todos os dados
  dynamic fetchAllData() {
    return state.data;
  }

  // reseta os dados
  Future reset() async {
    state = VisagismoState.initial();
  }
}

// Provider que expõe o AuthProvider
final visagismoProvider =
    StateNotifierProvider<VisagismoProvider, VisagismoState>((ref) {
  return VisagismoProvider();
});
