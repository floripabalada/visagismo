import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:vip_totem/util/global.dart';

class ThemeProvider extends ChangeNotifier {
  // pega da global
  bool isDark = themeIsDark;

  change() {
    // seta o valor
    isDark = !themeIsDark;

    // atualiza a global
    themeIsDark = isDark;

    notifyListeners();
  }
}

final themeProvider = ChangeNotifierProvider<ThemeProvider>((ref) {
  return ThemeProvider();
});
