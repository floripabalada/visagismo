import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class AuthProvider extends ChangeNotifier {
  Map<String, dynamic> user = {};

  login(Map<String, dynamic> data) {
    String name = data['nome'];
    String firstName = name.split(' ').first;

    // seta o primeiro nome do usário
    data['primeiro_nome'] = firstName;

    // define o user
    user = data;

    notifyListeners();
  }

  logout() {
    // remove os dados do usuário
    user = {};

    notifyListeners();
  }
}

final authProvider = ChangeNotifierProvider<AuthProvider>((ref) {
  return AuthProvider();
});
